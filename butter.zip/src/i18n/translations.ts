import type {
  AppLanguage,
  AppRegion,
  ExpenseCategory,
  GiftPlan,
  HabitItem,
  HomeCareTask,
  MoodLevel,
  NoteKind,
  PastelTone,
  ReminderSchedule,
  TaskCategory,
} from "../types/butter";

export interface LanguageMeta {
  id: AppLanguage;
  nativeName: string;
  englishName: string;
  flag: string;
  dir: "ltr" | "rtl";
  bcp47: string;
  pastel: PastelTone;
}

export const LANGUAGES: LanguageMeta[] = [
  { id: "en", nativeName: "English", englishName: "English", flag: "🇬🇧", dir: "ltr", bcp47: "en-US", pastel: "yellow" },
  { id: "ar", nativeName: "العربية", englishName: "Arabic", flag: "🇸🇦", dir: "rtl", bcp47: "ar-IQ", pastel: "sage" },
  { id: "ckb", nativeName: "کوردی", englishName: "Kurdish (Sorani)", flag: "🟡", dir: "rtl", bcp47: "ckb-IQ", pastel: "yellow" },
  { id: "tr", nativeName: "Türkçe", englishName: "Turkish", flag: "🇹🇷", dir: "ltr", bcp47: "tr-TR", pastel: "pink" },
  { id: "es", nativeName: "Español", englishName: "Spanish", flag: "🇪🇸", dir: "ltr", bcp47: "es-ES", pastel: "sky" },
  { id: "fr", nativeName: "Français", englishName: "French", flag: "🇫🇷", dir: "ltr", bcp47: "fr-FR", pastel: "lavender" },
  { id: "de", nativeName: "Deutsch", englishName: "German", flag: "🇩🇪", dir: "ltr", bcp47: "de-DE", pastel: "cream" },
  { id: "ko", nativeName: "한국어", englishName: "Korean", flag: "🇰🇷", dir: "ltr", bcp47: "ko-KR", pastel: "pink" },
  { id: "ja", nativeName: "日本語", englishName: "Japanese", flag: "🇯🇵", dir: "ltr", bcp47: "ja-JP", pastel: "sage" },
  { id: "zh", nativeName: "中文", englishName: "Chinese", flag: "🇨🇳", dir: "ltr", bcp47: "zh-CN", pastel: "sky" },
];

export const REGIONS: { id: AppRegion; label: string; localeSuffix: string }[] = [
  { id: "auto", label: "Auto (Language)", localeSuffix: "" },
  { id: "IQ", label: "Iraq (IQ)", localeSuffix: "IQ" },
  { id: "US", label: "United States (US)", localeSuffix: "US" },
  { id: "GB", label: "United Kingdom (GB)", localeSuffix: "GB" },
  { id: "TR", label: "Türkiye (TR)", localeSuffix: "TR" },
  { id: "ES", label: "Spain (ES)", localeSuffix: "ES" },
  { id: "FR", label: "France (FR)", localeSuffix: "FR" },
  { id: "DE", label: "Germany (DE)", localeSuffix: "DE" },
  { id: "KR", label: "South Korea (KR)", localeSuffix: "KR" },
  { id: "JP", label: "Japan (JP)", localeSuffix: "JP" },
  { id: "CN", label: "China (CN)", localeSuffix: "CN" },
];

export function getLanguageMeta(lang: AppLanguage): LanguageMeta {
  return LANGUAGES.find((l) => l.id === lang) || LANGUAGES[0];
}

export function normalizeLegacyLanguage(raw: unknown): AppLanguage {
  if (typeof raw !== "string") return "en";
  if (raw === "Arabic" || raw === "ar") return "ar";
  if (raw === "Kurdish" || raw === "ckb" || raw === "ku") return "ckb";
  if (raw === "English" || raw === "en") return "en";
  if (LANGUAGES.some((l) => l.id === raw)) return raw as AppLanguage;
  return "en";
}

export function getEffectiveLocale(language: AppLanguage, region: AppRegion): string {
  const meta = getLanguageMeta(language);
  const baseLang = language === "ckb" ? "ckb" : language;
  if (region && region !== "auto") {
    return `${baseLang}-${region}`;
  }
  return meta.bcp47;
}

const CKB_MONTHS = [
  "کانوونی دووەم",
  "شوبات",
  "ئازار",
  "نیسان",
  "ئایار",
  "حوزەیران",
  "تەممووز",
  "ئاب",
  "ئەیلوول",
  "تشرینی یەکەم",
  "تشرینی دووەم",
  "کانوونی یەکەم",
];

const CKB_WEEKDAYS = [
  "یەکشەممە",
  "دووشەممە",
  "سێشەممە",
  "چوارشەممە",
  "پێنجشەممە",
  "هەینی",
  "شەممە",
];

const CKB_WEEKDAYS_SHORT = ["یەک", "دوو", "سێ", "چوار", "پێنج", "هەینی", "شەم"];

export function formatLocaleDate(
  dateInput: Date | string,
  language: AppLanguage,
  region: AppRegion,
  style: "full" | "short" = "full"
): string {
  const date = typeof dateInput === "string" ? new Date(`${dateInput}T12:00:00`) : dateInput;
  if (Number.isNaN(date.getTime())) return String(dateInput);

  if (language === "ckb") {
    const day = date.getDate();
    const monthName = CKB_MONTHS[date.getMonth()];
    const weekday = CKB_WEEKDAYS[date.getDay()];
    return style === "full" ? `${weekday}، ${day} ${monthName}` : `${day} ${monthName}`;
  }

  const locale = getEffectiveLocale(language, region);
  try {
    return date.toLocaleDateString(
      locale,
      style === "full"
        ? { weekday: "long", month: "short", day: "numeric" }
        : { month: "short", day: "numeric", year: "numeric" }
    );
  } catch {
    return date.toLocaleDateString();
  }
}

export function formatMonthYear(date: Date, language: AppLanguage, region: AppRegion): string {
  if (language === "ckb") {
    return `${CKB_MONTHS[date.getMonth()]} ${date.getFullYear()}`;
  }
  const locale = getEffectiveLocale(language, region);
  try {
    return date.toLocaleDateString(locale, { month: "long", year: "numeric" });
  } catch {
    return date.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  }
}

export function getLocalizedWeekdays(language: AppLanguage, region: AppRegion): string[] {
  if (language === "ckb") return CKB_WEEKDAYS_SHORT;
  const locale = getEffectiveLocale(language, region);
  const baseSunday = new Date(2024, 0, 7); // Sunday
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(baseSunday);
    d.setDate(baseSunday.getDate() + i);
    try {
      return d.toLocaleDateString(locale, { weekday: "short" });
    } catch {
      return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][i];
    }
  });
}

export function formatLocaleNumber(num: number, language: AppLanguage, region: AppRegion): string {
  const locale = language === "ckb" ? (region !== "auto" ? `ar-${region}` : "ar-IQ") : getEffectiveLocale(language, region);
  try {
    return new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(num);
  } catch {
    return num.toLocaleString();
  }
}

export function formatLocaleMoney(
  amount: number,
  currency: "IQD" | "USD" | "EUR",
  language: AppLanguage,
  region: AppRegion
): string {
  const formatted = formatLocaleNumber(amount, language, region);
  if (currency === "IQD") return `${formatted} IQD`;
  const symbol = currency === "USD" ? "$" : "€";
  return `${symbol}${formatted}`;
}

export interface TranslationBundle {
  // Brand & Language Screen
  chooseLanguageTitle: string;
  chooseLanguageSub: string;
  changeLaterNote: string;
  languageUpdatedToast: string;

  // Splash & Onboarding
  splashTagline: string;
  skip: string;
  back: string;
  continueBtn: string;
  getStarted: string;
  slide1Title: string;
  slide1Sub: string;
  slide1Detail: string;
  slide2Title: string;
  slide2Sub: string;
  slide2Detail: string;
  slide3Title: string;
  slide3Sub: string;
  slide3Detail: string;

  // Navigation & Common Actions
  navHome: string;
  navPlan: string;
  navNotes: string;
  navMe: string;
  askButter: string;
  save: string;
  cancel: string;
  add: string;
  deleteLabel: string;
  editLabel: string;
  closeLabel: string;
  unlock: string;
  hide: string;

  // Home
  greetingMorning: string;
  greetingAfternoon: string;
  greetingEvening: string;
  homePromptNamed: string;
  homePromptDefault: string;
  upcomingBirthdayChip: string;
  editRoom: string;
  captionCelebrating: string;
  captionStudying: string;
  captionShopping: string;
  captionSelfcare: string;
  captionMusic: string;
  captionRelaxing: string;
  localWeather: string;
  weatherPrompt: string;
  useLocation: string;
  chooseCity: string;
  checkingSky: string;
  weatherUnavailable: string;
  weatherHighLow: string;
  weatherClear: string;
  weatherCloudy: string;
  weatherMisty: string;
  weatherRain: string;
  weatherSnow: string;
  weatherStorm: string;
  adviceChilly: string;
  adviceCool: string;
  adviceWarm: string;
  adviceRain: string;
  adviceSnow: string;
  adviceClear: string;
  adviceCloudy: string;
  moodTitle: string;
  moodGreat: string;
  moodGood: string;
  moodOkay: string;
  moodTired: string;
  moodLow: string;
  moodNotePlaceholder: string;
  quickAdd: string;
  quickReminder: string;
  quickList: string;
  quickMoney: string;
  quickAskButter: string;
  yourDay: string;
  makeDayEasier: string;
  fullPlan: string;
  gentleSuggestedOrder: string;
  nothingScheduledToday: string;
  addFirstPlan: string;
  placeAlertTag: string;
  activeRemindersLabel: string;
  windDown: string;
  windDownTomorrowCount: string;
  packAndGo: string;
  windDownBag: string;
  windDownCharge: string;
  windDownSchedule: string;
  exploreWorld: string;
  tilePack: string;
  tilePlaces: string;
  tileHomeCare: string;
  tileBirthdays: string;
  tileGifts: string;
  tileAutomations: string;

  // Plan & Calendar
  planTitle: string;
  planSubtitle: string;
  addPlan: string;
  viewToday: string;
  viewWeek: string;
  viewMonth: string;
  tomorrowLabel: string;
  thisWeekLabel: string;
  rightNowSub: string;
  upNextSub: string;
  gentleHorizonSub: string;
  quietAndOpen: string;
  noPlansThisDay: string;
  plansBirthdaysThisDay: string;
  muteAlert: string;
  moveBtn: string;
  eventTag: string;
  calendarEventBtn: string;
  personalTaskBtn: string;
  smartReminderLabel: string;
  newPlanModalTitle: string;
  editPlanModalTitle: string;
  planTitlePlaceholder: string;
  planTimePlaceholder: string;
  saveChanges: string;
  addToPlan: string;
  schedules: Record<ReminderSchedule, string>;
  taskCategories: Record<TaskCategory, string>;

  // Notes, Lists, Memories, Things
  notesTab: string;
  listsTab: string;
  memoriesTab: string;
  thingsTab: string;
  smartNotesTitle: string;
  smartNotesSub: string;
  listsSub: string;
  memoriesSub: string;
  thingsSub: string;
  newNote: string;
  editNote: string;
  newList: string;
  createCustomList: string;
  noteTitlePlaceholder: string;
  noteContentPlaceholder: string;
  saveNote: string;
  privateLabel: string;
  openLabel: string;
  privateNoteLocked: string;
  privateMemoryLocked: string;
  turnIntoShopping: string;
  turnIntoTask: string;
  checkedCount: string;
  addItemPlaceholder: string;
  saveMemoryTitle: string;
  memoryTitlePlaceholder: string;
  memoryNotePlaceholder: string;
  addPhotoOptional: string;
  photoAttached: string;
  privateMemoryBtn: string;
  visibleMemoryBtn: string;
  saveMemoryBtn: string;
  recordThingTitle: string;
  thingNamePlaceholder: string;
  thingLocPlaceholder: string;
  thingNotePlaceholder: string;
  saveItemBtn: string;
  locationPrefix: string;
  listNamePlaceholder: string;
  createListBtn: string;
  noteKinds: Record<NoteKind | "all", string>;

  // Money
  moneyTitle: string;
  moneySub: string;
  addSpending: string;
  todaySpending: string;
  thisWeekSpending: string;
  thisMonthSpending: string;
  spendingByCategory: string;
  recentSpending: string;
  noSpendingYet: string;
  savingsGoals: string;
  newGoal: string;
  logSpendingTitle: string;
  amountLabel: string;
  optionalNotePlaceholder: string;
  saveSpending: string;
  newSavingsGoalTitle: string;
  whatSavingFor: string;
  targetAmount: string;
  createGoal: string;
  saveQuickStep: string;
  expenseCategories: Record<ExpenseCategory, string>;

  // Me, Habits, Goals, Settings
  taglineFull: string;
  customizeAvatarRoom: string;
  myHabits: string;
  habitsSub: string;
  thisWeekProgress: string;
  addHabitPlaceholder: string;
  habitFrequencies: Record<HabitItem["frequency"], string>;
  myGoals: string;
  goalTitlePlaceholder: string;
  goalDescPlaceholder: string;
  goalStepsPlaceholder: string;
  savePersonalGoal: string;
  achievementsTitle: string;
  unlockedLabel: string;
  keepGoingGently: string;
  achWeek: string;
  achGoal: string;
  achMemory: string;
  achMonth: string;
  achOrganizer: string;
  personalizationTitle: string;
  softDay: string;
  cozyDusk: string;
  appAccentColor: string;
  homeCardArrangement: string;
  homeCardLabels: Record<"weather" | "avatar" | "your-day" | "wind-down" | "mood", string>;
  languageLabel: string;
  regionLabel: string;
  currencyLabel: string;
  textSizeLabel: string;
  textStandard: string;
  textLarge: string;
  textExtra: string;
  privacySecurityTitle: string;
  appLockTitle: string;
  appLockSub: string;
  pin4Digit: string;
  biometricLabel: string;
  weatherLocationMode: string;
  askOnHome: string;
  deviceLocation: string;
  manualCityOpt: string;
  notificationsChimes: string;
  reducedMotion: string;
  exportDataBtn: string;
  deleteAccountBtn: string;
  confirmDeleteBtn: string;

  // PWA & Offline
  installAppTitle: string;
  installAppSub: string;
  installAppBtn: string;
  installOnIOSBtn: string;
  installedAppBadge: string;
  iosInstallTitle: string;
  iosInstallStep1: string;
  iosInstallStep2: string;
  offlineBanner: string;
  gotItBtn: string;

  // Life Spaces
  packTitle: string;
  packSub: string;
  packSuggestPrompt: string;
  packPlaceholder: string;
  emptyKit: string;
  suggestItems: string;
  packedCount: string;
  placesTitle: string;
  placesSub: string;
  placeNamePh: string;
  placeNotePh: string;
  placeReminderPh: string;
  savePlace: string;
  arrivalReminder: string;
  homeCareTitle: string;
  homeCareSub: string;
  homeCarePlaceholder: string;
  addRoutine: string;
  homeCareSection: string;
  laundrySection: string;
  homeCareSchedules: Record<HomeCareTask["schedule"], string>;
  birthdaysTitle: string;
  giftsTitle: string;
  birthdaysGiftsSub: string;
  personNamePh: string;
  giftIdeaPh: string;
  saveBirthday: string;
  forWhoPh: string;
  budgetPh: string;
  dateExamplePh: string;
  addGift: string;
  statusLabel: string;
  giftStatuses: Record<GiftPlan["status"], string>;
  automationsTitle: string;
  automationsSub: string;
  whenPh: string;
  doPh: string;
  whenPrefix: string;
  trigDay: string;
  trigLocation: string;
  trigMonthly: string;
  trigTime: string;

  // Ask BUTTER & Quick Add
  askButterSubtitle: string;
  askButterPlaceholder: string;
  askButterExample1: string;
  askButterExample2: string;
  askButterChip1: string;
  askButterChip2: string;
  organizeBtn: string;
  confirmEditNote: string;
  confirmSaveItems: string;
  destPlan: string;
  destReminder: string;
  destShopping: string;
  destNote: string;
  destMoney: string;
  quickNewReminder: string;
  quickAddSomething: string;
  quickWhatTodo: string;
  quickTimeOpt: string;
  quickWhen: string;
  quickCategory: string;
  quickReminderOn: string;
  quickNoReminder: string;
  quickSaveBtn: string;

  // Avatar Studio
  studioTitle: string;
  studioSub: string;
  surpriseBtn: string;
  yourNameLabel: string;
  thisIsMe: string;
  tabLook: string;
  tabOutfit: string;
  tabExtras: string;
  tabRoom: string;
  characterStyle: string;
  skinTone: string;
  hairStyle: string;
  hairColor: string;
  dressesOrTwoPiece: string;
  dressColor: string;
  tops: string;
  bottoms: string;
  jackets: string;
  shoes: string;
  glassesLabel: string;
  hatsLabel: string;
  bagsLabel: string;
  headphonesLabel: string;
  smallAccLabel: string;
  roomUnlockedNote: string;
  roomBg: string;
  roomPlants: string;
  roomFurniture: string;
  roomPoster: string;
  roomDecor: string;
  rugTint: string;

  // App Lock & Toasts
  welcomeBackLock: string;
  enterPinHint: string;
  wrongPin: string;
  useFaceId: string;
  unlockPrivateTitle: string;
  toastSavedAvatar: string;
  toastSavedItems: string;
  toastExported: string;
  toastUnlocked: string;
  toastMood: string;
  toastSpending: string;
  toastGoal: string;
  toastPackCreated: string;
  toastPlaceSaved: string;
  toastRoutineAdded: string;
  toastBirthdaySaved: string;
  toastGiftSaved: string;
  toastAutoCreated: string;
  toastPlanAdded: string;
  toastNoteSaved: string;
  toastTurnedList: string;
  toastTurnedTask: string;
  toastListCreated: string;
  toastMemorySaved: string;
  toastThingSaved: string;
  toastReminderSet: string;
  toastAddedButter: string;
  errorGeneric: string;
}

const EN: TranslationBundle = {
  chooseLanguageTitle: "Choose your language 🌍",
  chooseLanguageSub: "BETTER adapts text, dates, calendars, and layout direction for you.",
  changeLaterNote: "You can change your language anytime later in Settings.",
  languageUpdatedToast: "Language updated 🌍",

  splashTagline: "Make your life better.",
  skip: "Skip",
  back: "Back",
  continueBtn: "Continue",
  getStarted: "Get Started ✨",
  slide1Title: "Welcome to BETTER ✨",
  slide1Sub: "Your little everyday life companion.",
  slide1Detail: "A soft, calm corner for your plans, notes, shopping lists, money, and daily rhythm.",
  slide2Title: "Organize your day 🌱",
  slide2Sub: "Keep your plans, reminders, notes and lists in one place.",
  slide2Detail: "Type naturally in any language with Ask BETTER ✨ and turn everyday thoughts into tidy cards.",
  slide3Title: "Make it yours 🫧",
  slide3Sub: "Create your own character and personalize your BETTER world.",
  slide3Detail: "Dress up your companion and watch them share your day with cozy reactions.",

  navHome: "Home",
  navPlan: "Plan",
  navNotes: "Notes",
  navMe: "Me",
  askButter: "Ask BETTER",
  save: "Save",
  cancel: "Cancel",
  add: "Add",
  deleteLabel: "Delete",
  editLabel: "Edit",
  closeLabel: "Close",
  unlock: "Unlock",
  hide: "Hide",

  greetingMorning: "Good morning!",
  greetingAfternoon: "Good afternoon!",
  greetingEvening: "Good evening!",
  homePromptNamed: "Hi {name}, what can BETTER help you with today?",
  homePromptDefault: "What can BETTER help you with today?",
  upcomingBirthdayChip: "🎂 {name}’s birthday is coming up ({date})",
  editRoom: "Edit Room",
  captionCelebrating: "{count} things done today — cheering you on ✨",
  captionStudying: "Holding a book for today's study plans 📚",
  captionShopping: "Tote bag packed for your errands 🛍️",
  captionSelfcare: "Tending to calm self-care near the plants 🌱",
  captionMusic: "Listening to soft cozy music 🎵",
  captionRelaxing: "Relaxing in your BETTER space 🫧",
  localWeather: "Local Weather",
  weatherPrompt: "Enable location for weather, or pick a city manually.",
  useLocation: "Use Location",
  chooseCity: "Choose City",
  checkingSky: "Checking the sky...",
  weatherUnavailable: "Location unavailable — pick a city instead.",
  weatherHighLow: "High {hi}° / Low {lo}°",
  weatherClear: "Clear & sunny",
  weatherCloudy: "Softly cloudy",
  weatherMisty: "Misty & cool",
  weatherRain: "Rain showers",
  weatherSnow: "Snowy chill",
  weatherStorm: "Breezy storm",
  adviceChilly: "Chilly air today. Wear a warm coat.",
  adviceCool: "Looks cool today. Take a light jacket.",
  adviceWarm: "Warm sunshine today. Dress light and bring water.",
  adviceRain: "Rain is expected today. Bring an umbrella and waterproof shoes.",
  adviceSnow: "Very chilly out. Bundle up with a warm coat and scarf.",
  adviceClear: "Bright skies today. Sunglasses and water are a good idea.",
  adviceCloudy: "Mild skies today. A light layer is plenty.",
  moodTitle: "Mood Check-in 🫧",
  moodGreat: "Great",
  moodGood: "Good",
  moodOkay: "Okay",
  moodTired: "Tired",
  moodLow: "Not great",
  moodNotePlaceholder: "Optional note before tapping a mood...",
  quickAdd: "Add Something",
  quickReminder: "Reminder",
  quickList: "Shopping",
  quickMoney: "Money",
  quickAskButter: "Ask BETTER",
  yourDay: "☀️ Today",
  makeDayEasier: "Make my day easier",
  fullPlan: "Full Plan",
  gentleSuggestedOrder: "✨ Gentle suggested order",
  nothingScheduledToday: "Nothing scheduled yet for today 🫧",
  addFirstPlan: "Add your first plan",
  placeAlertTag: "📍 Place alert",
  activeRemindersLabel: "⏰ Active reminders:",
  windDown: "Wind Down 🌙",
  windDownTomorrowCount: "Tomorrow has {count} gentle plan(s).",
  packAndGo: "Pack & Go 🎒",
  windDownBag: "🎒 Prepare bag",
  windDownCharge: "🔋 Charge device",
  windDownSchedule: "⏰ Check tomorrow",
  exploreWorld: "Explore your BETTER world",
  tilePack: "Pack & Go 🎒",
  tilePlaces: "My Places 📍",
  tileHomeCare: "Home & Laundry 🧺",
  tileBirthdays: "Birthdays 🎂",
  tileGifts: "Gift Planner 🎁",
  tileAutomations: "Automations 🪄",

  planTitle: "Smart Calendar & Plan",
  planSubtitle: "Today, week, month & smart reminders.",
  addPlan: "Add Plan",
  viewToday: "Today",
  viewWeek: "Week",
  viewMonth: "Month",
  tomorrowLabel: "Tomorrow",
  thisWeekLabel: "This Week",
  rightNowSub: "Right now",
  upNextSub: "Up next",
  gentleHorizonSub: "Gentle horizon",
  quietAndOpen: "Quiet and open 🫧",
  noPlansThisDay: "No plans on this day yet 🫧",
  plansBirthdaysThisDay: "Plans & birthdays on this day",
  muteAlert: "Mute Alert",
  moveBtn: "Move",
  eventTag: "Event",
  calendarEventBtn: "Calendar Event",
  personalTaskBtn: "Personal Task",
  smartReminderLabel: "⏰ Smart Reminder",
  newPlanModalTitle: "New Plan & Reminder",
  editPlanModalTitle: "Edit Plan",
  planTitlePlaceholder: "Title (e.g. Math homework, Dentist)",
  planTimePlaceholder: "Time (e.g. 6:00 PM)",
  saveChanges: "Save Changes",
  addToPlan: "Add to Plan",
  schedules: {
    once: "One-time",
    daily: "Every day",
    weekly: "Weekly",
    sunday: "Every Sunday",
    monthly: "Every month",
    location: "At saved place",
  },
  taskCategories: {
    general: "Daily",
    school: "School",
    homework: "Homework",
    shopping: "Shopping",
    food: "Food",
    selfcare: "Self-Care",
    errand: "Errand",
    money: "Money",
  },

  notesTab: "Notes 📝",
  listsTab: "Lists 🛍️",
  memoriesTab: "Memories 🫧",
  thingsTab: "My Things 📦",
  smartNotesTitle: "Smart Notes",
  smartNotesSub: "Capture thoughts and turn notes into tasks or lists in one tap.",
  listsSub: "Shopping runs and things to remember.",
  memoriesSub: "Your personal timeline of warm moments.",
  thingsSub: "Remember exactly where you placed important things.",
  newNote: "New Note",
  editNote: "Edit Note",
  newList: "New List",
  createCustomList: "Create Custom List 🛍️",
  noteTitlePlaceholder: "Title",
  noteContentPlaceholder: "Write a note, checklist, idea, shopping items, or memory...",
  saveNote: "Save Note",
  privateLabel: "Private",
  openLabel: "Open",
  privateNoteLocked: "🔒 Private note — tap to unlock",
  privateMemoryLocked: "🔒 Private memory — tap to unlock",
  turnIntoShopping: "Turn into shopping list ✨",
  turnIntoTask: "Turn into task ✨",
  checkedCount: "{done}/{total} checked",
  addItemPlaceholder: "Add an item...",
  saveMemoryTitle: "Save a Memory 🫧",
  memoryTitlePlaceholder: "Moment title...",
  memoryNotePlaceholder: "Write a short memory note...",
  addPhotoOptional: "Add photo (optional)",
  photoAttached: "Photo attached",
  privateMemoryBtn: "Private Memory",
  visibleMemoryBtn: "Visible",
  saveMemoryBtn: "Save Memory",
  recordThingTitle: "Record an Item Location 📦",
  thingNamePlaceholder: "Item (e.g. Passport, Charger)",
  thingLocPlaceholder: "Where is it? (e.g. Desk drawer)",
  thingNotePlaceholder: "Optional note...",
  saveItemBtn: "Save Item",
  locationPrefix: "Location:",
  listNamePlaceholder: "List name...",
  createListBtn: "Create List",
  noteKinds: {
    all: "All",
    note: "Normal",
    checklist: "Checklist",
    idea: "Idea",
    shopping: "Shopping",
    reminder: "Reminder",
    memory: "Memory",
  },

  moneyTitle: "Money",
  moneySub: "Your spending log & savings goals in one calm view.",
  addSpending: "Add Spending",
  todaySpending: "Today’s spending",
  thisWeekSpending: "This week",
  thisMonthSpending: "This month",
  spendingByCategory: "Spending by Category",
  recentSpending: "Recent Spending",
  noSpendingYet: "No spending logged yet 🫧",
  savingsGoals: "Savings Goals 🎯",
  newGoal: "New Goal",
  logSpendingTitle: "Log Spending 💰",
  amountLabel: "Amount",
  optionalNotePlaceholder: "Optional note...",
  saveSpending: "Save Spending",
  newSavingsGoalTitle: "New Savings Goal 🎯",
  whatSavingFor: "What are you saving for?",
  targetAmount: "Target amount",
  createGoal: "Create Goal",
  saveQuickStep: "+ Save {amount}",
  expenseCategories: {
    Food: "Food",
    Shopping: "Shopping",
    Transport: "Transport",
    Fun: "Fun",
    Bills: "Bills",
    "Self-Care": "Self-Care",
  },

  taglineFull: "BETTER · Make your life better",
  customizeAvatarRoom: "Customize Avatar & Room ✨",
  myHabits: "My Habits 🌱",
  habitsSub: "Gentle progress at your own pace — no stressful streak counters.",
  thisWeekProgress: "{done}/{target} this week",
  addHabitPlaceholder: "Add a gentle habit...",
  habitFrequencies: {
    Daily: "Daily",
    "3x / week": "3x / week",
    Weekends: "Weekends",
    Weekly: "Weekly",
  },
  myGoals: "My Goals 🎯",
  goalTitlePlaceholder: "Goal title (e.g. Learn guitar 🎸)",
  goalDescPlaceholder: "Short description...",
  goalStepsPlaceholder: "Small steps separated by commas...",
  savePersonalGoal: "Save Personal Goal",
  achievementsTitle: "Achievements 🏆",
  unlockedLabel: "Unlocked",
  keepGoingGently: "Keep going gently",
  achWeek: "First week with BETTER",
  achGoal: "Completed a personal goal",
  achMemory: "Memory keeper",
  achMonth: "30 days with BETTER",
  achOrganizer: "Calm organizer (5+ tasks)",
  personalizationTitle: "Personalization & Appearance",
  softDay: "☀️ Soft Day",
  cozyDusk: "🌙 Cozy Dusk",
  appAccentColor: "App Accent Color",
  homeCardArrangement: "Home Card Arrangement",
  homeCardLabels: {
    weather: "Weather 🌦️",
    avatar: "Avatar World 🫧",
    "your-day": "Your Day ☀️",
    "wind-down": "Wind Down 🌙",
    mood: "Mood Check-in 😊",
  },
  languageLabel: "Language",
  regionLabel: "Region (Dates & Numbers)",
  currencyLabel: "Currency",
  textSizeLabel: "Text Size (Accessibility)",
  textStandard: "Standard",
  textLarge: "Large",
  textExtra: "Extra",
  privacySecurityTitle: "Privacy, Security & Location",
  appLockTitle: "App Lock (PIN & Private Notes)",
  appLockSub: "Protects private notes, memories & app entry",
  pin4Digit: "4-digit PIN",
  biometricLabel: "Allow Face ID / Device Passkey unlock where supported",
  weatherLocationMode: "Weather Location Mode",
  askOnHome: "Ask on Home",
  deviceLocation: "Device Location",
  manualCityOpt: "Manual City",
  notificationsChimes: "Notifications & Chimes",
  reducedMotion: "Reduced Motion",
  exportDataBtn: "Export All My Data (JSON)",
  deleteAccountBtn: "Delete Account & Clear Local Data",
  confirmDeleteBtn: "Confirm Delete",

  packTitle: "Pack & Go 🎒",
  packSub: "Reusable checklists so you never forget the essentials.",
  packSuggestPrompt: "Create a checklist (or let BETTER suggest one ✨)",
  packPlaceholder: "e.g. Weekend Trip, Gym, Picnic, Art Class...",
  emptyKit: "Empty Kit",
  suggestItems: "Suggest Items ✨",
  packedCount: "{done}/{total} packed",
  placesTitle: "My Places 📍",
  placesSub: "Save favorite spots with notes and arrival reminders.",
  placeNamePh: "Place name (e.g. Library)",
  placeNotePh: "Helpful note...",
  placeReminderPh: "When I arrive, remind me...",
  savePlace: "Save Place",
  arrivalReminder: "Arrival reminder",
  homeCareTitle: "Home Care & Laundry",
  homeCareSub: "Gentle recurring routines without any pressure.",
  homeCarePlaceholder: "e.g. Clean desk, Wash sheets...",
  addRoutine: "Add Routine",
  homeCareSection: "Home Care 🌱",
  laundrySection: "Laundry Tracker 🧺",
  homeCareSchedules: {
    "Every 3 days": "Every 3 days",
    Weekly: "Weekly",
    "Bi-weekly": "Bi-weekly",
    Monthly: "Monthly",
  },
  birthdaysTitle: "Birthdays 🎂",
  giftsTitle: "Gift Planner 🎁",
  birthdaysGiftsSub: "Thoughtful dates, gift ideas, and calm budgets.",
  personNamePh: "Person's name",
  giftIdeaPh: "Optional gift idea...",
  saveBirthday: "Save Birthday",
  forWhoPh: "For who?",
  budgetPh: "Budget",
  dateExamplePh: "Date (e.g. Nov 24)",
  addGift: "Add Gift",
  statusLabel: "Status:",
  giftStatuses: {
    Idea: "Idea",
    Shopping: "Shopping",
    Wrapped: "Wrapped",
    Given: "Given",
  },
  automationsTitle: "BETTER Automations 🪄",
  automationsSub: "Simple When → Do helpers that quietly remember things for you.",
  whenPh: "When... (e.g. When it is Friday)",
  doPh: "Do... (e.g. Remind me to water plants)",
  whenPrefix: "WHEN",
  trigDay: "Weekly Day",
  trigLocation: "Saved Place",
  trigMonthly: "Monthly",
  trigTime: "Time",

  askButterSubtitle: "Plan, make lists, or ask in any language—even mixed sentences.",
  askButterPlaceholder: "e.g. Remind me to buy shampoo tomorrow / ذكرني أشتري شامبو باچر / I need to buy دفتر tomorrow",
  askButterExample1: "I need to buy a birthday gift tomorrow and finish my homework at night.",
  askButterExample2: "I need to buy دفتر tomorrow and remind me at 6 PM.",
  askButterChip1: "Try: \"Gift tomorrow & homework\"",
  askButterChip2: "Try mixed: \"Buy دفتر tomorrow\"",
  organizeBtn: "Organize ✨",
  confirmEditNote: "Confirm or edit before saving:",
  confirmSaveItems: "Confirm & Save {count} Items ✨",
  destPlan: "Plan",
  destReminder: "Reminder",
  destShopping: "Shopping List",
  destNote: "Notes",
  destMoney: "Money Log",
  quickNewReminder: "New Reminder ⏰",
  quickAddSomething: "Add Something 📝",
  quickWhatTodo: "What do you want to do?",
  quickTimeOpt: "Time (optional)",
  quickWhen: "When",
  quickCategory: "Category",
  quickReminderOn: "⏰ Reminder On",
  quickNoReminder: "No Reminder",
  quickSaveBtn: "Save to BETTER",

  studioTitle: "Create your character & room ✨",
  studioSub: "Customize your companion and cozy BETTER space — everything is unlocked and free.",
  surpriseBtn: "Surprise",
  yourNameLabel: "Your name or nickname",
  thisIsMe: "This is me! 🫧",
  tabLook: "Look",
  tabOutfit: "Outfit",
  tabExtras: "Extras",
  tabRoom: "Room 🪴",
  characterStyle: "Character Style",
  skinTone: "Skin Tone",
  hairStyle: "Hair Style",
  hairColor: "Hair Color",
  dressesOrTwoPiece: "Dresses or Two-Piece",
  dressColor: "Dress Color",
  tops: "Tops",
  bottoms: "Bottoms",
  jackets: "Jackets",
  shoes: "Shoes",
  glassesLabel: "Glasses",
  hatsLabel: "Hats",
  bagsLabel: "Bags",
  headphonesLabel: "Headphones",
  smallAccLabel: "Small Accessories",
  roomUnlockedNote: "All room pieces unlock naturally as you use BETTER — {count} tasks completed so far ✨",
  roomBg: "Room Background",
  roomPlants: "Plants",
  roomFurniture: "Furniture",
  roomPoster: "Wall Poster",
  roomDecor: "Decorations & Small Objects",
  rugTint: "Rug Tint",

  welcomeBackLock: "Welcome back to BETTER",
  enterPinHint: "Enter your 4-digit PIN (default 1234)",
  wrongPin: "Incorrect PIN — please try again.",
  useFaceId: "Use Face ID / Device Passkey",
  unlockPrivateTitle: "Unlock Private Items 🔒",
  toastSavedAvatar: "Character & room saved 🫧",
  toastSavedItems: "Saved {count} item(s) to BETTER ✨",
  toastExported: "Backup exported 📦",
  toastUnlocked: "Unlocked 🫧",
  toastMood: "Mood checked in 🫧",
  toastSpending: "Spending logged 💰",
  toastGoal: "Savings goal created 🎯",
  toastPackCreated: "Pack & Go kit created 🎒",
  toastPlaceSaved: "Place saved 📍",
  toastRoutineAdded: "Routine added 🌱",
  toastBirthdaySaved: "Birthday saved 🎂",
  toastGiftSaved: "Gift saved 🎁",
  toastAutoCreated: "Automation created 🪄",
  toastPlanAdded: "Added to Plan 📅",
  toastNoteSaved: "Note saved 📝",
  toastTurnedList: "Turned note into shopping list ✨",
  toastTurnedTask: "Turned note into today's task ✨",
  toastListCreated: "List created 🛍️",
  toastMemorySaved: "Memory saved 🫧",
  toastThingSaved: "Item location saved 📦",
  toastReminderSet: "Reminder set ⏰",
  toastAddedButter: "Added to BETTER ✨",
  errorGeneric: "Something went wrong. Please try again.",
  installAppTitle: "Install BETTER App",
  installAppSub: "Add BETTER to your Home Screen for a full-screen app experience and offline access.",
  installAppBtn: "Install BETTER",
  installOnIOSBtn: "Add to Home Screen",
  installedAppBadge: "App Installed",
  iosInstallTitle: "Install BETTER on iPhone or iPad",
  iosInstallStep1: "Tap the Share button in Safari's toolbar.",
  iosInstallStep2: "Scroll down and tap \"Add to Home Screen\".",
  offlineBanner: "You're offline — your saved BETTER plans, notes, and avatar still work.",
  gotItBtn: "Got it",
};

const AR: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "اختر لغتك 🌍",
  chooseLanguageSub: "يتكيّف BETTER تلقائياً مع النصوص والتواريخ والتقويم واتجاه الواجهة.",
  changeLaterNote: "يمكنك تغيير اللغة في أي وقت لاحقاً من الإعدادات.",
  languageUpdatedToast: "تم تحديث اللغة 🌍",

  splashTagline: "اجعل حياتك أفضل.",
  skip: "تخطي",
  back: "رجوع",
  continueBtn: "متابعة",
  getStarted: "ابدأ الآن ✨",
  slide1Title: "مرحباً بك في BETTER ✨",
  slide1Sub: "رفيقك اللطيف لحياتك اليومية.",
  slide1Detail: "مساحة هادئة لخططك وملاحظاتك وقوائم التسوق ومصاريفك وإيقاع يومك.",
  slide2Title: "نظّم يومك 🌱",
  slide2Sub: "احفظ خططك وتذكيراتك وملاحظاتك وقوائمك في مكان واحد.",
  slide2Detail: "اكتب بشكل طبيعي بأي لغة مع اسأل BETTER ✨ وحوّل أفكارك إلى بطاقات مرتبة.",
  slide3Title: "اجعله عالمك الخاص 🫧",
  slide3Sub: "صمّم شخصيتك وخصّص عالم BETTER الخاص بك.",
  slide3Detail: "زيّن رفيقك وشاهده يشاركك يومك بردود فعل لطيفة.",

  navHome: "الرئيسية",
  navPlan: "الخطط",
  navNotes: "الملاحظات",
  navMe: "أنا",
  askButter: "اسأل BETTER",
  save: "حفظ",
  cancel: "إلغاء",
  add: "إضافة",
  deleteLabel: "حذف",
  editLabel: "تعديل",
  closeLabel: "إغلاق",
  unlock: "فتح القفل",
  hide: "إخفاء",

  greetingMorning: "صباح الخير!",
  greetingAfternoon: "مساء النور!",
  greetingEvening: "مساء الخير!",
  homePromptNamed: "أهلاً {name}، بماذا يمكن أن يساعدك BETTER اليوم؟",
  homePromptDefault: "بماذا يمكن أن يساعدك BETTER اليوم؟",
  upcomingBirthdayChip: "🎂 عيد ميلاد {name} قريب ({date})",
  editRoom: "تعديل الغرفة",
  captionCelebrating: "أنجزت {count} مهام اليوم — فخور بك ✨",
  captionStudying: "يستعد مع كتاب لخطط الدراسة اليوم 📚",
  captionShopping: "الحقيبة جاهزة لمشاوير التسوق 🛍️",
  captionSelfcare: "لحظة هدوء وعناية بجانب النباتات 🌱",
  captionMusic: "يستمع إلى موسيقى هادئة 🎵",
  captionRelaxing: "يسترخي في عالم BETTER الخاص بك 🫧",
  localWeather: "الطقس المحلي",
  weatherPrompt: "فعّل الموقع لعرض الطقس، أو اختر مدينتك يدوياً.",
  useLocation: "استخدام الموقع",
  chooseCity: "اختيار مدينة",
  checkingSky: "جارٍ التحقق من الطقس...",
  weatherUnavailable: "الموقع غير متاح — اختر مدينة بدلاً من ذلك.",
  weatherHighLow: "العظمى {hi}° / الصغرى {lo}°",
  weatherClear: "صافٍ ومشمس",
  weatherCloudy: "غائم جزئياً",
  weatherMisty: "لطيف وضبابي",
  weatherRain: "زخات مطر",
  weatherSnow: "أجواء باردة مثلجة",
  weatherStorm: "عاصف وممطر",
  adviceChilly: "الجو بارد اليوم. ارتدِ معطفاً دافئاً.",
  adviceCool: "الجو لطيف ومائل للبرودة. خذ سترة خفيفة.",
  adviceWarm: "شمس دافئة اليوم. ارتدِ ملابس خفيفة واشرب الماء.",
  adviceRain: "يتوقع هطول أمطار اليوم. خذ مظلتك معك.",
  adviceSnow: "طقس شديد البرودة. ارتدِ ملابس دافئة ووشاحاً.",
  adviceClear: "سماء صافية اليوم. النظارات الشمسية والماء خيار رائع.",
  adviceCloudy: "سماء معتدلة اليوم. طبقة خفيفة تكفي.",
  moodTitle: "كيف مزاجك؟ 🫧",
  moodGreat: "رائع",
  moodGood: "جيد",
  moodOkay: "عادي",
  moodTired: "متعب",
  moodLow: "ليس بخير",
  moodNotePlaceholder: "ملاحظة اختيارية قبل اختيار المزاج...",
  quickAdd: "إضافة",
  quickReminder: "تذكير",
  quickList: "قائمة",
  quickMoney: "المال",
  quickAskButter: "اسأل BETTER",
  yourDay: "☀️ اليوم",
  makeDayEasier: "اجعل يومي أسهل",
  fullPlan: "الخطة الكاملة",
  gentleSuggestedOrder: "✨ ترتيب مقترح ومريح",
  nothingScheduledToday: "لا توجد مهام مجدولة لليوم بعد 🫧",
  addFirstPlan: "أضف خطتك الأولى",
  placeAlertTag: "📍 تنبيه مكان",
  activeRemindersLabel: "⏰ تذكيرات نشطة:",
  windDown: "استعداد المساء 🌙",
  windDownTomorrowCount: "غداً لديك {count} خطط لطيفة.",
  packAndGo: "جهّز الحقيبة 🎒",
  windDownBag: "🎒 تجهيز الحقيبة",
  windDownCharge: "🔋 شحن الجهاز",
  windDownSchedule: "⏰ مراجعة الغد",
  exploreWorld: "استكشف عالم BETTER",
  tilePack: "جهّز الحقيبة 🎒",
  tilePlaces: "أماكني 📍",
  tileHomeCare: "البيت والغسيل 🧺",
  tileBirthdays: "أعياد الميلاد 🎂",
  tileGifts: "تخطيط الهدايا 🎁",
  tileAutomations: "الأتمتة 🪄",

  planTitle: "التقويم والخطط الذكية",
  planSubtitle: "اليوم والأسبوع والشهر والتذكيرات الذكية.",
  addPlan: "إضافة خطة",
  viewToday: "اليوم",
  viewWeek: "الأسبوع",
  viewMonth: "الشهر",
  tomorrowLabel: "غداً",
  thisWeekLabel: "هذا الأسبوع",
  rightNowSub: "الآن",
  upNextSub: "القادم",
  gentleHorizonSub: "خلال الأيام القادمة",
  quietAndOpen: "هادئ ومتاح 🫧",
  noPlansThisDay: "لا توجد خطط في هذا اليوم بعد 🫧",
  plansBirthdaysThisDay: "خطط وأعياد ميلاد هذا اليوم",
  muteAlert: "كتم التنبيه",
  moveBtn: "نقل",
  eventTag: "موعد",
  calendarEventBtn: "حدث في التقويم",
  personalTaskBtn: "مهمة شخصية",
  smartReminderLabel: "⏰ تذكير ذكي",
  newPlanModalTitle: "خطة وتذكير جديد",
  editPlanModalTitle: "تعديل الخطة",
  planTitlePlaceholder: "العنوان (مثلاً: واجب الرياضيات، طبيب الأسنان)",
  planTimePlaceholder: "الوقت (مثلاً: 6:00 مساءً)",
  saveChanges: "حفظ التغييرات",
  addToPlan: "إضافة للخطة",
  schedules: {
    once: "مرة واحدة",
    daily: "كل يوم",
    weekly: "أسبوعياً",
    sunday: "كل أحد",
    monthly: "كل شهر",
    location: "عند الوصول للمكان",
  },
  taskCategories: {
    general: "يومي",
    school: "دراسة",
    homework: "واجب",
    shopping: "تسوق",
    food: "طعام",
    selfcare: "عناية ذاتية",
    errand: "مشوار",
    money: "مال",
  },

  notesTab: "الملاحظات 📝",
  listsTab: "القوائم 🛍️",
  memoriesTab: "الذكريات 🫧",
  thingsTab: "أشيائي 📦",
  smartNotesTitle: "الملاحظات الذكية",
  smartNotesSub: "سجّل أفكارك وحوّل الملاحظات إلى مهام أو قوائم تسوق بلمسة واحدة.",
  listsSub: "قوائم التسوق والأشياء المهمة التي لا تريد نسيانها.",
  memoriesSub: "شريط ذكرياتك ولحظاتك الدافئة.",
  thingsSub: "تذكّر أين وضعت أشياءك المهمة دائماً.",
  newNote: "ملاحظة جديدة",
  editNote: "تعديل الملاحظة",
  newList: "قائمة جديدة",
  createCustomList: "إنشاء قائمة مخصصة 🛍️",
  noteTitlePlaceholder: "العنوان",
  noteContentPlaceholder: "اكتب ملاحظة أو قائمة أو فكرة أو أغراض تسوق...",
  saveNote: "حفظ الملاحظة",
  privateLabel: "خاص",
  openLabel: "عام",
  privateNoteLocked: "🔒 ملاحظة خاصة — اضغط لفتحها",
  privateMemoryLocked: "🔒 ذكرى خاصة — اضغط لفتحها",
  turnIntoShopping: "تحويل إلى قائمة تسوق ✨",
  turnIntoTask: "تحويل إلى مهمة ✨",
  checkedCount: "تم إنجاز {done}/{total}",
  addItemPlaceholder: "أضف عنصراً...",
  saveMemoryTitle: "حفظ ذكرى 🫧",
  memoryTitlePlaceholder: "عنوان اللحظة...",
  memoryNotePlaceholder: "اكتب وصفاً قصيراً للذكرى...",
  addPhotoOptional: "إضافة صورة (اختياري)",
  photoAttached: "تم إرفاق الصورة",
  privateMemoryBtn: "ذكرى خاصة",
  visibleMemoryBtn: "مرئية",
  saveMemoryBtn: "حفظ الذكرى",
  recordThingTitle: "تذكر مكان غرض مهم 📦",
  thingNamePlaceholder: "الغرض (مثل: جواز السفر، الشاحن)",
  thingLocPlaceholder: "أين وضعته؟ (مثل: درج المكتب)",
  thingNotePlaceholder: "ملاحظة إضافية...",
  saveItemBtn: "حفظ الغرض",
  locationPrefix: "المكان:",
  listNamePlaceholder: "اسم القائمة...",
  createListBtn: "إنشاء القائمة",
  noteKinds: {
    all: "الكل",
    note: "عادي",
    checklist: "قائمة تحقق",
    idea: "فكرة",
    shopping: "تسوق",
    reminder: "تذكير",
    memory: "ذكرى",
  },

  moneyTitle: "المال والمصاريف",
  moneySub: "متابعة مصاريفك وأهداف الادخار بهدوء ووضوح.",
  addSpending: "إضافة مصروف",
  todaySpending: "مصاريف اليوم",
  thisWeekSpending: "هذا الأسبوع",
  thisMonthSpending: "هذا الشهر",
  spendingByCategory: "المصاريف حسب الفئة",
  recentSpending: "آخر المصاريف",
  noSpendingYet: "لم تسجل أي مصاريف بعد 🫧",
  savingsGoals: "أهداف الادخار 🎯",
  newGoal: "هدف جديد",
  logSpendingTitle: "تسجيل مصروف 💰",
  amountLabel: "المبلغ",
  optionalNotePlaceholder: "ملاحظة اختيارية...",
  saveSpending: "حفظ المصروف",
  newSavingsGoalTitle: "هدف ادخار جديد 🎯",
  whatSavingFor: "ما الذي تدخر من أجله؟",
  targetAmount: "المبلغ المستهدف",
  createGoal: "إنشاء الهدف",
  saveQuickStep: "+ ادخر {amount}",
  expenseCategories: {
    Food: "طعام",
    Shopping: "تسوق",
    Transport: "مواصلات",
    Fun: "ترفيه",
    Bills: "فواتير",
    "Self-Care": "عناية ذاتية",
  },

  taglineFull: "BETTER · اجعل حياتك أفضل",
  customizeAvatarRoom: "تخصيص الشخصية والغرفة ✨",
  myHabits: "عاداتي 🌱",
  habitsSub: "تقدّم لطيف على راحتك — بدون ضغط أو عدّادات توتر.",
  thisWeekProgress: "{done}/{target} هذا الأسبوع",
  addHabitPlaceholder: "أضف عادة لطيفة...",
  habitFrequencies: {
    Daily: "يومياً",
    "3x / week": "3 مرات أسبوعياً",
    Weekends: "عطلة نهاية الأسبوع",
    Weekly: "أسبوعياً",
  },
  myGoals: "أهدافي 🎯",
  goalTitlePlaceholder: "عنوان الهدف (مثل: تعلم العزف 🎸)",
  goalDescPlaceholder: "وصف قصير...",
  goalStepsPlaceholder: "خطوات صغيرة مفصولة بفاصلة...",
  savePersonalGoal: "حفظ الهدف الشخصي",
  achievementsTitle: "الإنجازات 🏆",
  unlockedLabel: "مكتمل",
  keepGoingGently: "استمر بلطف",
  achWeek: "الأسبوع الأول مع BETTER",
  achGoal: "إتمام هدف شخصي",
  achMemory: "حافظ الذكريات",
  achMonth: "30 يوماً مع BETTER",
  achOrganizer: "منظم هادئ (5+ مهام)",
  personalizationTitle: "التخصيص والمظهر",
  softDay: "☀️ نهار هادئ",
  cozyDusk: "🌙 مساء دافئ",
  appAccentColor: "لون التطبيق",
  homeCardArrangement: "ترتيب بطاقات الرئيسية",
  homeCardLabels: {
    weather: "الطقس 🌦️",
    avatar: "عالم الشخصية 🫧",
    "your-day": "يومك ☀️",
    "wind-down": "استعداد المساء 🌙",
    mood: "المزاج 😊",
  },
  languageLabel: "اللغة",
  regionLabel: "المنطقة (التاريخ والأرقام)",
  currencyLabel: "العملة",
  textSizeLabel: "حجم الخط",
  textStandard: "قياسي",
  textLarge: "كبير",
  textExtra: "كبير جداً",
  privacySecurityTitle: "الخصوصية والأمان والموقع",
  appLockTitle: "قفل التطبيق والملاحظات الخاصة",
  appLockSub: "يحمي الملاحظات والذكريات الخاصة والدخول للتطبيق",
  pin4Digit: "رمز PIN من 4 أرقام",
  biometricLabel: "السماح بفتح القفل بالوجه أو بصمة الجهاز عند التوفر",
  weatherLocationMode: "وضع موقع الطقس",
  askOnHome: "اسأل في الرئيسية",
  deviceLocation: "موقع الجهاز",
  manualCityOpt: "مدينة محددة",
  notificationsChimes: "الإشعارات والتنبيهات",
  reducedMotion: "تقليل الحركة",
  exportDataBtn: "تصدير جميع بياناتي (JSON)",
  deleteAccountBtn: "حذف الحساب ومسح البيانات المحلية",
  confirmDeleteBtn: "تأكيد الحذف",

  packTitle: "جهّز الحقيبة 🎒",
  packSub: "قوائم متكررة حتى لا تنسى أشياءك الأساسية.",
  packSuggestPrompt: "أنشئ قائمة جديدة (أو دع BETTER يقترحها لك ✨)",
  packPlaceholder: "مثل: رحلة عطلة، نادي رياضي، جامعة...",
  emptyKit: "قائمة فارغة",
  suggestItems: "اقتراح عناصر ✨",
  packedCount: "تم تجهيز {done}/{total}",
  placesTitle: "أماكني 📍",
  placesSub: "احفظ أماكنك المهمة مع ملاحظات وتذكيرات الوصول.",
  placeNamePh: "اسم المكان (مثل: المكتبة)",
  placeNotePh: "ملاحظة مفيدة...",
  placeReminderPh: "عندما أصل هنا، ذكّرني بـ...",
  savePlace: "حفظ المكان",
  arrivalReminder: "تذكير الوصول",
  homeCareTitle: "العناية بالبيت والغسيل",
  homeCareSub: "روتين منزلي لطيف بدون أي ضغط.",
  homeCarePlaceholder: "مثل: ترتيب المكتب، غسيل الملابس...",
  addRoutine: "إضافة روتين",
  homeCareSection: "العناية بالبيت 🌱",
  laundrySection: "متابعة الغسيل 🧺",
  homeCareSchedules: {
    "Every 3 days": "كل 3 أيام",
    Weekly: "أسبوعياً",
    "Bi-weekly": "كل أسبوعين",
    Monthly: "شهرياً",
  },
  birthdaysTitle: "أعياد الميلاد 🎂",
  giftsTitle: "تخطيط الهدايا 🎁",
  birthdaysGiftsSub: "تواريخ مهمة وأفكار هدايا وميزانية هادئة.",
  personNamePh: "اسم الشخص",
  giftIdeaPh: "فكرة هدية اختيارية...",
  saveBirthday: "حفظ عيد الميلاد",
  forWhoPh: "لمن الهدية؟",
  budgetPh: "الميزانية",
  dateExamplePh: "التاريخ (مثل: 24 نوفمبر)",
  addGift: "إضافة هدية",
  statusLabel: "الحالة:",
  giftStatuses: {
    Idea: "فكرة",
    Shopping: "قيد الشراء",
    Wrapped: "مغلفة",
    Given: "مُهداة",
  },
  automationsTitle: "أتمتة BETTER 🪄",
  automationsSub: "قواعد بسيطة (عندما ← افعل) تتذكر عنك بهدوء.",
  whenPh: "عندما... (مثل: عندما يكون يوم الجمعة)",
  doPh: "افعل... (مثل: ذكّرني بسقي النباتات)",
  whenPrefix: "عندما",
  trigDay: "يوم أسبوعي",
  trigLocation: "مكان محفوظ",
  trigMonthly: "شهرياً",
  trigTime: "وقت محدد",

  askButterSubtitle: "خطط أو أنشئ قوائم بأي لغة أو حتى بجمل مختلطة.",
  askButterPlaceholder: "مثال: ذكرني أشتري شامبو باچر، أو I need to buy دفتر tomorrow",
  askButterExample1: "ذكرني أشتري شامبو باچر وأخلص واجبي بالليل.",
  askButterExample2: "I need to buy دفتر tomorrow الساعة 6 مساءً.",
  askButterChip1: "جرّب: \"شامبو باچر والواجب\"",
  askButterChip2: "جرّب مختلط: \"Buy دفتر tomorrow\"",
  organizeBtn: "تنظيم ✨",
  confirmEditNote: "راجع أو عدّل قبل الحفظ:",
  confirmSaveItems: "تأكيد وحفظ {count} عناصر ✨",
  destPlan: "الخطة",
  destReminder: "تذكير",
  destShopping: "قائمة تسوق",
  destNote: "ملاحظات",
  destMoney: "سجل المال",
  quickNewReminder: "تذكير جديد ⏰",
  quickAddSomething: "إضافة شيء جديد 📝",
  quickWhatTodo: "ما الذي تريد فعله؟",
  quickTimeOpt: "الوقت (اختياري)",
  quickWhen: "متى",
  quickCategory: "الفئة",
  quickReminderOn: "⏰ التذكير مفعل",
  quickNoReminder: "بدون تذكير",
  quickSaveBtn: "حفظ في BETTER",

  studioTitle: "صمّم شخصيتك وغرفتك ✨",
  studioSub: "خصّص رفيقك ومساحتك الدافئة — كل الخيارات مفتوحة ومجانية.",
  surpriseBtn: "مفاجأة",
  yourNameLabel: "اسمك أو لقبك",
  thisIsMe: "هذا أنا! 🫧",
  tabLook: "المظهر",
  tabOutfit: "الملابس",
  tabExtras: "إكسسوارات",
  tabRoom: "الغرفة 🪴",
  characterStyle: "نمط الشخصية",
  skinTone: "لون البشرة",
  hairStyle: "تسريحة الشعر",
  hairColor: "لون الشعر",
  dressesOrTwoPiece: "فستان أو قطعتين",
  dressColor: "لون الفستان",
  tops: "القطع العلوية",
  bottoms: "القطع السفلية",
  jackets: "السترات",
  shoes: "الأحذية",
  glassesLabel: "النظارات",
  hatsLabel: "القبعات",
  bagsLabel: "الحقائب",
  headphonesLabel: "السماعات",
  smallAccLabel: "تفاصيل صغيرة",
  roomUnlockedNote: "تتفتح عناصر الغرفة تلقائياً مع استخدامك — أنجزت {count} مهام حتى الآن ✨",
  roomBg: "خلفية الغرفة",
  roomPlants: "النباتات",
  roomFurniture: "الأثاث",
  roomPoster: "ملصق الحائط",
  roomDecor: "الزينة والأغراض",
  rugTint: "لون السجادة",

  welcomeBackLock: "أهلاً بعودتك إلى BETTER",
  enterPinHint: "أدخل رمز PIN من 4 أرقام (الافتراضي 1234)",
  wrongPin: "الرمز غير صحيح — حاول مرة أخرى.",
  useFaceId: "استخدام بصمة الوجه أو رمز الجهاز",
  unlockPrivateTitle: "فتح العناصر الخاصة 🔒",
  toastSavedAvatar: "تم حفظ الشخصية والغرفة 🫧",
  toastSavedItems: "تم حفظ {count} عناصر في BETTER ✨",
  toastExported: "تم تصدير النسخة الاحتياطية 📦",
  toastUnlocked: "تم فتح القفل 🫧",
  toastMood: "تم تسجيل المزاج 🫧",
  toastSpending: "تم تسجيل المصروف 💰",
  toastGoal: "تم إنشاء هدف الادخار 🎯",
  toastPackCreated: "تم إنشاء قائمة الحقيبة 🎒",
  toastPlaceSaved: "تم حفظ المكان 📍",
  toastRoutineAdded: "تمت إضافة الروتين 🌱",
  toastBirthdaySaved: "تم حفظ عيد الميلاد 🎂",
  toastGiftSaved: "تم حفظ الهدية 🎁",
  toastAutoCreated: "تم إنشاء الأتمتة 🪄",
  toastPlanAdded: "تمت الإضافة إلى الخطة 📅",
  toastNoteSaved: "تم حفظ الملاحظة 📝",
  toastTurnedList: "تم تحويل الملاحظة إلى قائمة تسوق ✨",
  toastTurnedTask: "تم تحويل الملاحظة إلى مهمة اليوم ✨",
  toastListCreated: "تم إنشاء القائمة 🛍️",
  toastMemorySaved: "تم حفظ الذكرى 🫧",
  toastThingSaved: "تم حفظ مكان الغرض 📦",
  toastReminderSet: "تم ضبط التذكير ⏰",
  toastAddedButter: "تمت الإضافة إلى BETTER ✨",
  errorGeneric: "حدث خطأ بسيط، يرجى المحاولة مرة أخرى.",
  installAppTitle: "تثبيت تطبيق BETTER",
  installAppSub: "أضف BETTER إلى شاشتك الرئيسية لتجربة تطبيق كاملة والوصول بدون إنترنت.",
  installAppBtn: "تثبيت BETTER",
  installOnIOSBtn: "إضافة إلى الشاشة الرئيسية",
  installedAppBadge: "التطبيق مثبّت",
  iosInstallTitle: "تثبيت BETTER على آيفون أو آيباد",
  iosInstallStep1: "اضغط على زر المشاركة في شريط متصفح سفاري.",
  iosInstallStep2: "مرّر للأسفل واختر «إضافة إلى الصفحة الرئيسية».",
  offlineBanner: "أنت غير متصل بالإنترنت — خططك وملاحظاتك وشخصيتك المحفوظة لا تزال تعمل.",
  gotItBtn: "حسناً",
};

const CKB: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "زمانەکەت هەڵبژێرە 🌍",
  chooseLanguageSub: "BETTER دەق و بەروار و ڕۆژژمێر و ئاڕاستەی ڕووکار بە شێوەی خۆکار دەگونجێنێت.",
  changeLaterNote: "دواتر لە ڕێکخستنەکاندا دەتوانیت هەر کاتێک بتەوێت زمانەکە بگۆڕیت.",
  languageUpdatedToast: "زمان نوێکرایەوە 🌍",

  splashTagline: "ژیانت باشتر بکە.",
  skip: "تێپەڕاندن",
  back: "گەڕانەوە",
  continueBtn: "بەردەوامبە",
  getStarted: "دەست پێبکە ✨",
  slide1Title: "بەخێربێیت بۆ BETTER ✨",
  slide1Sub: "هاوڕێ بچووکەکەت بۆ ژیانی ڕۆژانە.",
  slide1Detail: "شوێنێکی ئارام بۆ پلان و تێبینی و لیستی بازاڕ و خەرجی و ڕیتمی ڕۆژانەت.",
  slide2Title: "ڕۆژەکەت ڕێکبخە 🌱",
  slide2Sub: "پلان و یادخەرەوە و تێبینی و لیستەکانت لە یەک شوێن کۆبکەرەوە.",
  slide2Detail: "بە سروشتی بە هەر زمانێک بنووسە لەگەڵ پرسیار لە BETTER ✨ و بیرۆکەکانت بکە بە کارتی ڕێک.",
  slide3Title: "بیکە بە هی خۆت 🫧",
  slide3Sub: "کارەکتەری خۆت دروست بکە و جیهانی BETTER بڕازێنەرەوە.",
  slide3Detail: "هاوڕێکەت بگۆڕە و بیبینە لەگەڵ چالاکییەکانی ڕۆژانەت کاردانەوەی جوانی هەیە.",

  navHome: "سەرەکی",
  navPlan: "پلان",
  navNotes: "تێبینی",
  navMe: "من",
  askButter: "پرسیار لە BETTER",
  save: "پاشەکەوت",
  cancel: "پاشگەزبوونەوە",
  add: "زیادکردن",
  deleteLabel: "سڕینەوە",
  editLabel: "دەستکاری",
  closeLabel: "داخستن",
  unlock: "کردنەوە",
  hide: "شاردنەوە",

  greetingMorning: "بەیانیت باش!",
  greetingAfternoon: "نیوەڕۆت باش!",
  greetingEvening: "ئێوارەت باش!",
  homePromptNamed: "سڵاو {name}، ئەمڕۆ BETTER چۆن یارمەتیت بدات؟",
  homePromptDefault: "ئەمڕۆ BETTER چۆن یارمەتیت بدات؟",
  upcomingBirthdayChip: "🎂 ڕۆژی لەدایکبوونی {name} نزیکە ({date})",
  editRoom: "دەستکاری ژوور",
  captionCelebrating: "ئەمڕۆ {count} کارت تەواو کرد — ئافەرین ✨",
  captionStudying: "کتێبێکی بەدەستەوەیە بۆ پلانی خوێندنی ئەمڕۆ 📚",
  captionShopping: "جانتاکە ئامادەیە بۆ کارەکانی دەرەوە 🛍️",
  captionSelfcare: "لە لای ڕووەکەکاندا ئارامی و گرنگیدان بە خۆ 🌱",
  captionMusic: "گوێ لە مۆسیقایەکی هێمن دەگرێت 🎵",
  captionRelaxing: "لە شوێنی BETTERـی خۆتدا پشوو دەدات 🫧",
  localWeather: "کەشوهەوای ناوخۆ",
  weatherPrompt: "مۆڵەتی شوێن بدە بۆ کەشوهەوا، یان شارێک بە دەستی هەڵبژێرە.",
  useLocation: "بەکارهێنانی شوێن",
  chooseCity: "هەڵبژاردنی شار",
  checkingSky: "پشکنینی ئاسمان...",
  weatherUnavailable: "شوێن بەردەست نییە — شارێک هەڵبژێرە.",
  weatherHighLow: "بەرزترین {hi}° / نزمترین {lo}°",
  weatherClear: "ساماڵ و خۆرەتاو",
  weatherCloudy: "کەمێک هەوراوی",
  weatherMisty: "فێنک و تەماوی",
  weatherRain: "باراناوی",
  weatherSnow: "سارد و بەفراوی",
  weatherStorm: "با و باران",
  adviceChilly: "ئەمڕۆ ساردە. چاکەتێکی گەرم لەبەر بکە.",
  adviceCool: "کەش فێنکە. چاکەتێکی سووک لەگەڵ خۆت ببە.",
  adviceWarm: "خۆرەتاو و گەرمە. جلی سووک لەبەر بکە و ئاو ببە.",
  adviceRain: "ئەگەری باران هەیە. چەترێک لەگەڵ خۆت ببە.",
  adviceSnow: "زۆر ساردە. خۆت گەرم دابپۆشە.",
  adviceClear: "ئاسمان ڕوونە. چاویلکەی خۆر و ئاو باش دەبن.",
  adviceCloudy: "کەشێکی مامناوەندە. جلێکی سووک بەسە.",
  moodTitle: "هەستی ئەمڕۆ 🫧",
  moodGreat: "زۆر باش",
  moodGood: "باش",
  moodOkay: "ئاسایی",
  moodTired: "ماندوو",
  moodLow: "باش نیم",
  moodNotePlaceholder: "تێبینییەکی کورت پێش هەڵبژاردن...",
  quickAdd: "زیادکردن",
  quickReminder: "یادخەرەوە",
  quickList: "لیست",
  quickMoney: "پارە",
  quickAskButter: "پرسیار",
  yourDay: "☀️ ئەمڕۆ",
  makeDayEasier: "ڕۆژەکەم ئاسانتر بکە",
  fullPlan: "پلانی تەواو",
  gentleSuggestedOrder: "✨ ڕیزبەندی پێشنیارکراوی ئارام",
  nothingScheduledToday: "هێشتا هیچ پلانێک بۆ ئەمڕۆ دانەنراوە 🫧",
  addFirstPlan: "یەکەم پلانت زیاد بکە",
  placeAlertTag: "📍 ئاگادارکردنەوەی شوێن",
  activeRemindersLabel: "⏰ یادخەرەوە چالاکەکان:",
  windDown: "ئامادەکاری ئێوارە 🌙",
  windDownTomorrowCount: "سبەینێ {count} پلانی ئارامت هەیە.",
  packAndGo: "پێچانەوە 🎒",
  windDownBag: "🎒 ئامادەکردنی جانتا",
  windDownCharge: "🔋 شەحنکردنی ئامێر",
  windDownSchedule: "⏰ سەیرکردنی سبەینێ",
  exploreWorld: "جیهانی BETTER بگەڕێ",
  tilePack: "پێچانەوە 🎒",
  tilePlaces: "شوێنەکانم 📍",
  tileHomeCare: "ماڵ و جلشۆرین 🧺",
  tileBirthdays: "ڕۆژی لەدایکبوون 🎂",
  tileGifts: "پلانی دیاری 🎁",
  tileAutomations: "خۆکارییەکان 🪄",

  planTitle: "ڕۆژژمێر و پلانی زیرەک",
  planSubtitle: "ئەمڕۆ و هەفتە و مانگ و یادخەرەوە زیرەکەکان.",
  addPlan: "پلان زیاد بکە",
  viewToday: "ئەمڕۆ",
  viewWeek: "هەفتە",
  viewMonth: "مانگ",
  tomorrowLabel: "سبەینێ",
  thisWeekLabel: "ئەم هەفتەیە",
  rightNowSub: "ئێستا",
  upNextSub: "داهاتوو",
  gentleHorizonSub: "ڕۆژانی داهاتوو",
  quietAndOpen: "ئارام و کراوەیە 🫧",
  noPlansThisDay: "هیچ پلانێک بۆ ئەم ڕۆژە نییە 🫧",
  plansBirthdaysThisDay: "پلان و ڕۆژانی لەدایکبوونی ئەم ڕۆژە",
  muteAlert: "بێدەنگکردن",
  moveBtn: "گواستنەوە",
  eventTag: "بۆنە",
  calendarEventBtn: "بۆنەی ڕۆژژمێر",
  personalTaskBtn: "ئەرکی کەسی",
  smartReminderLabel: "⏰ یادخەرەوەی زیرەک",
  newPlanModalTitle: "پلان و یادخەرەوەی نوێ",
  editPlanModalTitle: "دەستکاری پلان",
  planTitlePlaceholder: "ناونیشان (بۆ نموونە: ئەرکی بیرکاری، پزیشک)",
  planTimePlaceholder: "کات (بۆ نموونە: 6:00 ئێوارە)",
  saveChanges: "پاشەکەوتکردن",
  addToPlan: "زیادکردن بۆ پلان",
  schedules: {
    once: "یەک جار",
    daily: "هەموو ڕۆژێک",
    weekly: "هەفتانە",
    sunday: "هەموو یەکشەممەیەک",
    monthly: "هەموو مانگێک",
    location: "لە شوێنی پاشەکەوتکراو",
  },
  taskCategories: {
    general: "ڕۆژانە",
    school: "قوتابخانە",
    homework: "ئەرک",
    shopping: "بازاڕ",
    food: "خواردن",
    selfcare: "گرنگیدان بە خۆ",
    errand: "کاروبار",
    money: "پارە",
  },

  notesTab: "تێبینی 📝",
  listsTab: "لیستەکان 🛍️",
  memoriesTab: "یادەوەری 🫧",
  thingsTab: "شتەکانم 📦",
  smartNotesTitle: "تێبینی زیرەک",
  smartNotesSub: "بیرۆکەکانت بنووسە و بە یەک کلیک بیانکە بە ئەرک یان لیستی بازاڕ.",
  listsSub: "لیستی بازاڕ و ئەو شتانەی دەتەوێت لەبیرت بمێنن.",
  memoriesSub: "تۆماری کاتە گەرم و خۆشەکانت.",
  thingsSub: "بە وردی بزانە شتە گرنگەکانت لە کوێ داناوە.",
  newNote: "تێبینی نوێ",
  editNote: "دەستکاری تێبینی",
  newList: "لیستی نوێ",
  createCustomList: "دروستکردنی لیستی نوێ 🛍️",
  noteTitlePlaceholder: "ناونیشان",
  noteContentPlaceholder: "تێبینی، لیست، بیرۆکە، یان شتی بازاڕ بنووسە...",
  saveNote: "پاشەکەوتی تێبینی",
  privateLabel: "تایبەت",
  openLabel: "کراوە",
  privateNoteLocked: "🔒 تێبینی تایبەت — کلیک بکە بۆ کردنەوە",
  privateMemoryLocked: "🔒 یادەوەری تایبەت — کلیک بکە بۆ کردنەوە",
  turnIntoShopping: "بیکە بە لیستی بازاڕ ✨",
  turnIntoTask: "بیکە بە ئەرک ✨",
  checkedCount: "{done}/{total} تەواوکراوە",
  addItemPlaceholder: "شتێک زیاد بکە...",
  saveMemoryTitle: "یادەوەرییەک پاشەکەوت بکە 🫧",
  memoryTitlePlaceholder: "ناونیشانی ساتەکە...",
  memoryNotePlaceholder: "تێبینییەکی کورت لەسەر یادەوەرییەکە بنووسە...",
  addPhotoOptional: "وێنە زیاد بکە (ئارەزوومەندانە)",
  photoAttached: "وێنەکە هاوپێچ کرا",
  privateMemoryBtn: "یادەوەری تایبەت",
  visibleMemoryBtn: "بینراو",
  saveMemoryBtn: "پاشەکەوتی یادەوەری",
  recordThingTitle: "شوێنی شتێک تۆمار بکە 📦",
  thingNamePlaceholder: "شتەکە (وەک: پاسپۆرت، شەحن)",
  thingLocPlaceholder: "لە کوێیە؟ (وەک: چەکمەجەی مێز)",
  thingNotePlaceholder: "تێبینی زیادە...",
  saveItemBtn: "پاشەکەوتی شت",
  locationPrefix: "شوێن:",
  listNamePlaceholder: "ناوی لیست...",
  createListBtn: "دروستکردنی لیست",
  noteKinds: {
    all: "هەموو",
    note: "ئاسایی",
    checklist: "لیست",
    idea: "بیرۆکە",
    shopping: "بازاڕ",
    reminder: "یادخەرەوە",
    memory: "یادەوەری",
  },

  moneyTitle: "پارە",
  moneySub: "خەرجییەکانت و ئامانجەکانی پاشەکەوت لە یەک شوێنی ئارامدا.",
  addSpending: "خەرجی زیاد بکە",
  todaySpending: "خەرجی ئەمڕۆ",
  thisWeekSpending: "ئەم هەفتەیە",
  thisMonthSpending: "ئەم مانگە",
  spendingByCategory: "خەرجی بەپێی پۆل",
  recentSpending: "خەرجییەکانی دوایی",
  noSpendingYet: "هێشتا هیچ خەرجییەک تۆمار نەکراوە 🫧",
  savingsGoals: "ئامانجەکانی پاشەکەوت 🎯",
  newGoal: "ئامانجی نوێ",
  logSpendingTitle: "تۆمارکردنی خەرجی 💰",
  amountLabel: "بڕ",
  optionalNotePlaceholder: "تێبینی ئارەزوومەندانە...",
  saveSpending: "پاشەکەوتی خەرجی",
  newSavingsGoalTitle: "ئامانجی پاشەکەوتی نوێ 🎯",
  whatSavingFor: "بۆ چی پاشەکەوت دەکەیت؟",
  targetAmount: "بڕی مەبەست",
  createGoal: "دروستکردنی ئامانج",
  saveQuickStep: "+ {amount} پاشەکەوت بکە",
  expenseCategories: {
    Food: "خواردن",
    Shopping: "بازاڕ",
    Transport: "هاتوچۆ",
    Fun: "کات بەسەربردن",
    Bills: "پسووڵەکان",
    "Self-Care": "گرنگیدان بە خۆ",
  },

  taglineFull: "BETTER · ژیانت باشتر بکە",
  customizeAvatarRoom: "دەستکاری کارەکتەر و ژوور ✨",
  myHabits: "خووەکانم 🌱",
  habitsSub: "پێشکەوتنی ئارام بە ڕیتمی خۆت — بەبێ هیچ فشارێک.",
  thisWeekProgress: "{done}/{target} ئەم هەفتەیە",
  addHabitPlaceholder: "خوویەکی ئارام زیاد بکە...",
  habitFrequencies: {
    Daily: "ڕۆژانە",
    "3x / week": "٣ جار لە هەفتەدا",
    Weekends: "کۆتایی هەفتە",
    Weekly: "هەفتانە",
  },
  myGoals: "ئامانجەکانم 🎯",
  goalTitlePlaceholder: "ناونیشانی ئامانج (وەک: فێربوونی گیتار 🎸)",
  goalDescPlaceholder: "کورتەیەک...",
  goalStepsPlaceholder: "هەنگاوە بچووکەکان بە کۆما جیاکراونەتەوە...",
  savePersonalGoal: "پاشەکەوتی ئامانج",
  achievementsTitle: "دەستکەوتەکان 🏆",
  unlockedLabel: "کراوەتەوە",
  keepGoingGently: "بە هێمنی بەردەوامبە",
  achWeek: "یەکەم هەفتە لەگەڵ BETTER",
  achGoal: "تەواوکردنی ئامانجێکی کەسی",
  achMemory: "پارێزەری یادەوەری",
  achMonth: "٣٠ ڕۆژ لەگەڵ BETTER",
  achOrganizer: "ڕێکخەری ئارام (٥+ ئەرک)",
  personalizationTitle: "کەسایەتیکردن و ڕووکار",
  softDay: "☀️ ڕۆژی نەرم",
  cozyDusk: "🌙 ئێوارەی گەرم",
  appAccentColor: "ڕەنگی ئەپ",
  homeCardArrangement: "ڕیزبەندی کارتەکانی سەرەکی",
  homeCardLabels: {
    weather: "کەشوهەوا 🌦️",
    avatar: "جیهانی کارەکتەر 🫧",
    "your-day": "ڕۆژەکەت ☀️",
    "wind-down": "ئامادەکاری ئێوارە 🌙",
    mood: "هەستی ئەمڕۆ 😊",
  },
  languageLabel: "زمان",
  regionLabel: "ناوچە (بەروار و ژمارەکان)",
  currencyLabel: "دراو",
  textSizeLabel: "قەبارەی دەق",
  textStandard: "ئاسایی",
  textLarge: "گەورە",
  textExtra: "زۆر گەورە",
  privacySecurityTitle: "نهێنی، پاراستن و شوێن",
  appLockTitle: "قوفڵی ئەپ و تێبینی تایبەت",
  appLockSub: "تێبینی و یادەوەری تایبەت و چوونەژوورەوە دەپارێزێت",
  pin4Digit: "کۆدی ٤ ژمارەیی",
  biometricLabel: "ڕێگەدان بە کردنەوە بە ڕوخسار یان پەنجەمۆر ئەگەر بەردەست بێت",
  weatherLocationMode: "شێوازی شوێنی کەشوهەوا",
  askOnHome: "پرسیار لە سەرەکی",
  deviceLocation: "شوێنی ئامێر",
  manualCityOpt: "هەڵبژاردنی شار",
  notificationsChimes: "ئاگادارکردنەوە و دەنگ",
  reducedMotion: "کەمکردنەوەی جووڵە",
  exportDataBtn: "هەناردەکردنی هەموو داتاکانم (JSON)",
  deleteAccountBtn: "سڕینەوەی هەژمار و پاککردنەوەی داتاکان",
  confirmDeleteBtn: "دڵنیاکردنەوەی سڕینەوە",

  packTitle: "پێچانەوە 🎒",
  packSub: "لیستی دووبارە بەکارهێنراو تا هیچ شتێکت بیر نەچێت.",
  packSuggestPrompt: "لیستێک دروست بکە (یان با BETTER پێشنیاری بکات ✨)",
  packPlaceholder: "وەک: گەشتی کۆتایی هەفتە، وەرزش، زانکۆ...",
  emptyKit: "لیستی بەتاڵ",
  suggestItems: "پێشنیاری شتەکان ✨",
  packedCount: "{done}/{total} پێچراوەتەوە",
  placesTitle: "شوێنەکانم 📍",
  placesSub: "شوێنە گرنگەکانت لەگەڵ تێبینی و یادخەرەوەی گەیشتن هەڵبگرە.",
  placeNamePh: "ناوی شوێن (وەک: کتێبخانە)",
  placeNotePh: "تێبینی سوودبەخش...",
  placeReminderPh: "کاتێک دەگەمە ئێرە، بیرم بخەرەوە...",
  savePlace: "پاشەکەوتی شوێن",
  arrivalReminder: "یادخەرەوەی گەیشتن",
  homeCareTitle: "گرنگیدان بە ماڵ و جلشۆرین",
  homeCareSub: "ڕۆتینی ئارامی ماڵەوە بەبێ هیچ گوشارێک.",
  homeCarePlaceholder: "وەک: ڕێکخستنی مێز، شۆردنی جل...",
  addRoutine: "زیادکردنی ڕۆتین",
  homeCareSection: "گرنگیدان بە ماڵ 🌱",
  laundrySection: "چاودێری جلشۆرین 🧺",
  homeCareSchedules: {
    "Every 3 days": "هەموو ٣ ڕۆژ جارێک",
    Weekly: "هەفتانە",
    "Bi-weekly": "دوو هەفتە جارێک",
    Monthly: "مانگانە",
  },
  birthdaysTitle: "ڕۆژی لەدایکبوون 🎂",
  giftsTitle: "پلانی دیاری 🎁",
  birthdaysGiftsSub: "بەروارە خۆشەکان، بیرۆکەی دیاری و بودجەی هێمن.",
  personNamePh: "ناوی کەسەکە",
  giftIdeaPh: "بیرۆکەی دیاری...",
  saveBirthday: "پاشەکەوتی ڕۆژی لەدایکبوون",
  forWhoPh: "بۆ کێ؟",
  budgetPh: "بودجە",
  dateExamplePh: "بەروار (وەک: ٢٤ی نۆڤەمبەر)",
  addGift: "زیادکردنی دیاری",
  statusLabel: "دۆخ:",
  giftStatuses: {
    Idea: "بیرۆکە",
    Shopping: "لە کڕیندا",
    Wrapped: "پێچراوەتەوە",
    Given: "بەخشرا",
  },
  automationsTitle: "خۆکارییەکانی BETTER 🪄",
  automationsSub: "یاسای سادەی (کاتێک ← ئەنجام بدە) بە هێمنی لەبیرت دەهێنێتەوە.",
  whenPh: "کاتێک... (وەک: کاتێک ڕۆژی هەینییە)",
  doPh: "بکە... (وەک: بیرم بخەرەوە ئاو بدەمە گوڵەکان)",
  whenPrefix: "کاتێک",
  trigDay: "ڕۆژی هەفتە",
  trigLocation: "شوێنی هەڵگیراو",
  trigMonthly: "مانگانە",
  trigTime: "کات",

  askButterSubtitle: "بە هەر زمانێک یان تێکەڵیش بنووسە — BETTER تێدەگات.",
  askButterPlaceholder: "نموونە: سبەی بیرم بخەرەوە شامپۆ بکڕم، یان I need to buy دفتر tomorrow",
  askButterExample1: "سبەی بیرم بخەرەوە شامپۆ بکڕم و شەویش ئەرکەکەم تەواو بکەم.",
  askButterExample2: "I need to buy دفتر tomorrow کاتژمێر ٦.",
  askButterChip1: "تاقی بکەرەوە: \"سبەی شامپۆ و ئەرک\"",
  askButterChip2: "تێکەڵ: \"Buy دفتر tomorrow\"",
  organizeBtn: "ڕێکخستن ✨",
  confirmEditNote: "پشتڕاست بکەرەوە یان دەستکاری بکە پێش پاشەکەوت:",
  confirmSaveItems: "پشتڕاستکردنەوە و پاشەکەوتی {count} شت ✨",
  destPlan: "پلان",
  destReminder: "یادخەرەوە",
  destShopping: "لیستی بازاڕ",
  destNote: "تێبینی",
  destMoney: "پارە",
  quickNewReminder: "یادخەرەوەی نوێ ⏰",
  quickAddSomething: "شتێک زیاد بکە 📝",
  quickWhatTodo: "دەتەوێت چی بکەیت؟",
  quickTimeOpt: "کات (ئارەزوومەندانە)",
  quickWhen: "کەی",
  quickCategory: "پۆل",
  quickReminderOn: "⏰ یادخەرەوە چالاکە",
  quickNoReminder: "بێ یادخەرەوە",
  quickSaveBtn: "پاشەکەوت لە BETTER",

  studioTitle: "کارەکتەر و ژوورەکەت دروست بکە ✨",
  studioSub: "هاوڕێکەت و شوێنە گەرمەکەت ڕێکبخە — هەموو شتێک کراوەیە و بێبەرامبەرە.",
  surpriseBtn: "سەرسوڕهێنەر",
  yourNameLabel: "ناو یان نازناوەکەت",
  thisIsMe: "ئەمە منم! 🫧",
  tabLook: "شێوە",
  tabOutfit: "جلوبەرگ",
  tabExtras: "وردەکاری",
  tabRoom: "ژوور 🪴",
  characterStyle: "شێوازی کارەکتەر",
  skinTone: "ڕەنگی پێست",
  hairStyle: "شێوازی قژ",
  hairColor: "ڕەنگی قژ",
  dressesOrTwoPiece: "عەزی یان دوو پارچە",
  dressColor: "ڕەنگی عەزی",
  tops: "سەرەوە",
  bottoms: "خوارەوە",
  jackets: "چاکەت",
  shoes: "پێڵاو",
  glassesLabel: "چاویلکە",
  hatsLabel: "کڵاو",
  bagsLabel: "جانتا",
  headphonesLabel: "بیستۆک",
  smallAccLabel: "ئیکسسواراتی بچووک",
  roomUnlockedNote: "هەموو بەشەکانی ژوور بەکارهێنانت دەکرێنەوە — تا ئێستا {count} کار تەواو بووە ✨",
  roomBg: "باکگراوندی ژوور",
  roomPlants: "ڕووەکەکان",
  roomFurniture: "کەلوپەل",
  roomPoster: "پۆستەری دیوار",
  roomDecor: "ڕازاندنەوە",
  rugTint: "ڕەنگی فەرش",

  welcomeBackLock: "بەخێربێیتەوە بۆ BETTER",
  enterPinHint: "کۆدی ٤ ژمارەیی بنووسە (بنەڕەتی 1234)",
  wrongPin: "کۆدەکە هەڵەیە — دووبارە هەوڵبدە.",
  useFaceId: "بەکارهێنانی ناسینەوەی ڕوخسار یان کۆدی ئامێر",
  unlockPrivateTitle: "کردنەوەی بەشە تایبەتەکان 🔒",
  toastSavedAvatar: "کارەکتەر و ژوور پاشەکەوت کران 🫧",
  toastSavedItems: "{count} شت لە BETTER پاشەکەوت کرا ✨",
  toastExported: "پاشەکەوت هەناردە کرا 📦",
  toastUnlocked: "کرایەوە 🫧",
  toastMood: "هەستی ئەمڕۆ تۆمار کرا 🫧",
  toastSpending: "خەرجی تۆمار کرا 💰",
  toastGoal: "ئامانجی پاشەکەوت دروست کرا 🎯",
  toastPackCreated: "لیستی پێچانەوە دروست کرا 🎒",
  toastPlaceSaved: "شوێن پاشەکەوت کرا 📍",
  toastRoutineAdded: "ڕۆتین زیاد کرا 🌱",
  toastBirthdaySaved: "ڕۆژی لەدایکبوون پاشەکەوت کرا 🎂",
  toastGiftSaved: "دیاری پاشەکەوت کرا 🎁",
  toastAutoCreated: "خۆکاری دروست کرا 🪄",
  toastPlanAdded: "زیاد کرا بۆ پلان 📅",
  toastNoteSaved: "تێبینی پاشەکەوت کرا 📝",
  toastTurnedList: "تێبینی کرا بە لیستی بازاڕ ✨",
  toastTurnedTask: "تێبینی کرا بە ئەرکی ئەمڕۆ ✨",
  toastListCreated: "لیست دروست کرا 🛍️",
  toastMemorySaved: "یادەوەری پاشەکەوت کرا 🫧",
  toastThingSaved: "شوێنی شتەکە پاشەکەوت کرا 📦",
  toastReminderSet: "یادخەرەوە دانرا ⏰",
  toastAddedButter: "زیاد کرا بۆ BETTER ✨",
  errorGeneric: "هەڵەیەک ڕوویدا، تکایە دووبارە هەوڵبدە.",
  installAppTitle: "دامەزراندنی ئەپی BETTER",
  installAppSub: "BETTER زیاد بکە بۆ شاشەی سەرەکی بۆ ئەزموونێکی تەواوی ئەپ و بەکارهێنانی بێ ئینتەرنێت.",
  installAppBtn: "دامەزراندنی BETTER",
  installOnIOSBtn: "زیادکردن بۆ شاشەی سەرەکی",
  installedAppBadge: "ئەپەکە دامەزراوە",
  iosInstallTitle: "دامەزراندنی BETTER لەسەر ئایفۆن یان ئایپاد",
  iosInstallStep1: "لە سەفاریدا کرتە لە دوگمەی هاوبەشکردن (Share) بکە.",
  iosInstallStep2: "بڕۆ خوارەوە و «Add to Home Screen» هەڵبژێرە.",
  offlineBanner: "هێڵی ئینتەرنێت پچڕاوە — پلان و تێبینی و کارەکتەرە پاشەکەوتکراوەکانت هێشتا کاردەکەن.",
  gotItBtn: "تێگەیشتم",
};

const TR: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "Dilini seç 🌍",
  chooseLanguageSub: "BETTER metinleri, tarihleri, takvimi ve düzeni diline göre uyarlar.",
  changeLaterNote: "Dilini istediğin zaman Ayarlar’dan değiştirebilirsin.",
  languageUpdatedToast: "Dil güncellendi 🌍",
  splashTagline: "Hayatını daha güzel yap.",
  skip: "Atla",
  back: "Geri",
  continueBtn: "Devam",
  getStarted: "Başlayalım ✨",
  slide1Title: "BETTER'a Hoş Geldin ✨",
  slide1Sub: "Günlük hayatının sevimli yol arkadaşı.",
  slide1Detail: "Planların, notların, alışveriş listelerin, paran ve günlük düzenin için sakin bir köşe.",
  slide2Title: "Gününü düzenle 🌱",
  slide2Sub: "Planlarını, hatırlatıcılarını, notlarını ve listelerini tek yerde tut.",
  slide2Detail: "Ask BETTER ✨ ile istediğin dilde doğal yaz, düşüncelerini düzenli kartlara dönüştür.",
  slide3Title: "Kendine göre tasarla 🫧",
  slide3Sub: "Kendi karakterini oluştur ve BETTER dünyanı kişiselleştir.",
  slide3Detail: "Karakterini giydir ve gün boyu tatlı tepkilerini izle.",
  navHome: "Ana Sayfa",
  navPlan: "Plan",
  navNotes: "Notlar",
  navMe: "Ben",
  askButter: "BETTER'a Sor",
  save: "Kaydet",
  cancel: "İptal",
  add: "Ekle",
  deleteLabel: "Sil",
  editLabel: "Düzenle",
  closeLabel: "Kapat",
  unlock: "Kilidi Aç",
  hide: "Gizle",
  greetingMorning: "Günaydın!",
  greetingAfternoon: "İyi öğleden sonralar!",
  greetingEvening: "İyi akşamlar!",
  homePromptNamed: "Merhaba {name}, BETTER bugün sana nasıl yardımcı olabilir?",
  homePromptDefault: "BETTER bugün sana nasıl yardımcı olabilir?",
  upcomingBirthdayChip: "🎂 {name} yakında doğum gününü kutluyor ({date})",
  editRoom: "Odayı Düzenle",
  localWeather: "Yerel Hava Durumu",
  useLocation: "Konum Kullan",
  chooseCity: "Şehir Seç",
  checkingSky: "Gökyüzüne bakılıyor...",
  moodTitle: "Ruh Halin 🫧",
  moodGreat: "Harika",
  moodGood: "İyi",
  moodOkay: "İdare eder",
  moodTired: "Yorgun",
  moodLow: "Pek iyi değil",
  quickAdd: "Ekle",
  quickReminder: "Hatırlatıcı",
  quickList: "Alışveriş",
  quickMoney: "Para",
  quickAskButter: "BETTER'a Sor",
  yourDay: "☀️ Bugün",
  makeDayEasier: "Günümü kolaylaştır",
  fullPlan: "Tüm Plan",
  windDown: "Akşam Hazırlığı 🌙",
  packAndGo: "Hazırla & Çık 🎒",
  exploreWorld: "BETTER dünyanı keşfet",
  planTitle: "Akıllı Takvim & Plan",
  planSubtitle: "Bugün, hafta, ay ve akıllı hatırlatıcılar.",
  addPlan: "Plan Ekle",
  viewToday: "Bugün",
  viewWeek: "Hafta",
  viewMonth: "Ay",
  tomorrowLabel: "Yarın",
  thisWeekLabel: "Bu Hafta",
  notesTab: "Notlar 📝",
  listsTab: "Listeler 🛍️",
  memoriesTab: "Anılar 🫧",
  thingsTab: "Eşyalarım 📦",
  moneyTitle: "Para",
  moneySub: "Harcamaların ve birikim hedeflerin sakin bir görünümde.",
  addSpending: "Harcama Ekle",
  todaySpending: "Bugünkü harcama",
  thisWeekSpending: "Bu hafta",
  thisMonthSpending: "Bu ay",
  spendingByCategory: "Kategoriye Göre Harcama",
  recentSpending: "Son Harcamalar",
  savingsGoals: "Birikim Hedefleri 🎯",
  newGoal: "Yeni Hedef",
  expenseCategories: { Food: "Yemek", Shopping: "Alışveriş", Transport: "Ulaşım", Fun: "Eğlence", Bills: "Faturalar", "Self-Care": "Kişisel Bakım" },
  taglineFull: "BETTER · Hayatını daha güzel yap",
  customizeAvatarRoom: "Karakter & Odayı Özelleştir ✨",
  myHabits: "Alışkanlıklarım 🌱",
  myGoals: "Hedeflerim 🎯",
  achievementsTitle: "Başarılar 🏆",
  personalizationTitle: "Kişiselleştirme & Görünüm",
  softDay: "☀️ Yumuşak Gündüz",
  cozyDusk: "🌙 Sıcak Akşam",
  languageLabel: "Dil",
  regionLabel: "Bölge (Tarih ve Sayılar)",
  currencyLabel: "Para Birimi",
  studioTitle: "Karakterini ve odanı oluştur ✨",
  thisIsMe: "Bu benim! 🫧",
  tabLook: "Görünüm",
  tabOutfit: "Kıyafet",
  tabExtras: "Ekstralar",
  tabRoom: "Oda 🪴",
  organizeBtn: "Düzenle ✨",
  schedules: { once: "Tek sefer", daily: "Her gün", weekly: "Haftalık", sunday: "Her Pazar", monthly: "Her ay", location: "Kayıtlı yerde" },
  taskCategories: { general: "Günlük", school: "Okul", homework: "Ödev", shopping: "Alışveriş", food: "Yemek", selfcare: "Bakım", errand: "İş", money: "Para" },
  noteKinds: { all: "Tümü", note: "Normal", checklist: "Liste", idea: "Fikir", shopping: "Alışveriş", reminder: "Hatırlatıcı", memory: "Anı" },
  habitFrequencies: { Daily: "Günlük", "3x / week": "Haftada 3", Weekends: "Hafta sonu", Weekly: "Haftalık" },
  giftStatuses: { Idea: "Fikir", Shopping: "Alınıyor", Wrapped: "Paketlendi", Given: "Verildi" },
  destPlan: "Plan",
  destReminder: "Hatırlatıcı",
  destShopping: "Alışveriş Listesi",
  destNote: "Notlar",
  destMoney: "Para Kaydı",
  askButterSubtitle: "Herhangi bir dilde veya karışık cümlelerle yazabilirsin.",
  askButterPlaceholder: "Örn: Yarın şampuan almayı hatırlat / I need to buy دفتر tomorrow",
  askButterExample1: "Yarın doğum günü hediyesi almayı ve akşam ödevimi bitirmeyi hatırlat.",
  askButterExample2: "I need to buy دفتر tomorrow saat 18:00.",
  askButterChip1: "Dene: \"Yarın hediye & ödev\"",
  askButterChip2: "Karışık: \"Buy دفتر tomorrow\"",
  confirmEditNote: "Kaydetmeden önce onayla veya düzenle:",
  confirmSaveItems: "{count} öğeyi onayla ve kaydet ✨",
  quickNewReminder: "Yeni Hatırlatıcı ⏰",
  quickAddSomething: "Yeni Ekle 📝",
  quickWhatTodo: "Ne yapmak istiyorsun?",
  quickSaveBtn: "BETTER'a Kaydet",
  toastSavedAvatar: "Karakter ve oda kaydedildi 🫧",
  toastSavedItems: "{count} öğe BETTER'a kaydedildi ✨",
  errorGeneric: "Bir sorun oluştu. Lütfen tekrar dene.",
};

const ES: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "Elige tu idioma 🌍",
  chooseLanguageSub: "BETTER adapta textos, fechas, calendario y dirección visual para ti.",
  changeLaterNote: "Puedes cambiar el idioma cuando quieras en Ajustes.",
  languageUpdatedToast: "Idioma actualizado 🌍",
  splashTagline: "Haz tu vida mejor.",
  skip: "Saltar",
  back: "Atrás",
  continueBtn: "Continuar",
  getStarted: "Comenzar ✨",
  slide1Title: "Bienvenido a BETTER ✨",
  slide1Sub: "Tu pequeño compañero para la vida diaria.",
  slide1Detail: "Un rincón suave y tranquilo para tus planes, notas, listas, dinero y rutina.",
  slide2Title: "Organiza tu día 🌱",
  slide2Sub: "Guarda tus planes, recordatorios, notas y listas en un solo lugar.",
  slide2Detail: "Escribe con naturalidad en cualquier idioma con Ask BETTER ✨.",
  slide3Title: "Hazlo tuyo 🫧",
  slide3Sub: "Crea tu personaje y personaliza tu mundo BETTER.",
  slide3Detail: "Viste a tu compañero y mira sus reacciones acogedoras.",
  navHome: "Inicio",
  navPlan: "Plan",
  navNotes: "Notas",
  navMe: "Yo",
  askButter: "Pregunta a BETTER",
  save: "Guardar",
  cancel: "Cancelar",
  add: "Añadir",
  deleteLabel: "Eliminar",
  editLabel: "Editar",
  closeLabel: "Cerrar",
  unlock: "Desbloquear",
  hide: "Ocultar",
  greetingMorning: "¡Buenos días!",
  greetingAfternoon: "¡Buenas tardes!",
  greetingEvening: "¡Buenas noches!",
  homePromptNamed: "Hola {name}, ¿en qué te ayuda BETTER hoy?",
  homePromptDefault: "¿En qué te ayuda BETTER hoy?",
  editRoom: "Editar sala",
  localWeather: "Clima local",
  useLocation: "Usar ubicación",
  chooseCity: "Elegir ciudad",
  moodTitle: "Estado de ánimo 🫧",
  moodGreat: "Genial",
  moodGood: "Bien",
  moodOkay: "Normal",
  moodTired: "Cansado",
  moodLow: "Bajo",
  quickAdd: "Añadir",
  quickReminder: "Aviso",
  quickList: "Compras",
  quickMoney: "Dinero",
  quickAskButter: "Ask BETTER",
  yourDay: "☀️ Hoy",
  makeDayEasier: "Haz mi día más fácil",
  fullPlan: "Plan completo",
  windDown: "Cierre del día 🌙",
  packAndGo: "Mochila 🎒",
  exploreWorld: "Explora tu mundo BETTER",
  planTitle: "Calendario y Plan",
  planSubtitle: "Hoy, semana, mes y recordatorios inteligentes.",
  addPlan: "Añadir plan",
  viewToday: "Hoy",
  viewWeek: "Semana",
  viewMonth: "Mes",
  tomorrowLabel: "Mañana",
  thisWeekLabel: "Esta semana",
  notesTab: "Notas 📝",
  listsTab: "Listas 🛍️",
  memoriesTab: "Recuerdos 🫧",
  thingsTab: "Mis Cosas 📦",
  moneyTitle: "Dinero",
  moneySub: "Tus gastos y metas de ahorro en una vista tranquila.",
  addSpending: "Añadir gasto",
  todaySpending: "Gasto de hoy",
  thisWeekSpending: "Esta semana",
  thisMonthSpending: "Este mes",
  spendingByCategory: "Gastos por categoría",
  recentSpending: "Gastos recientes",
  savingsGoals: "Metas de ahorro 🎯",
  newGoal: "Nueva meta",
  expenseCategories: { Food: "Comida", Shopping: "Compras", Transport: "Transporte", Fun: "Ocio", Bills: "Facturas", "Self-Care": "Cuidado" },
  customizeAvatarRoom: "Personalizar avatar y sala ✨",
  myHabits: "Mis hábitos 🌱",
  myGoals: "Mis metas 🎯",
  achievementsTitle: "Logros 🏆",
  personalizationTitle: "Personalización y Apariencia",
  softDay: "☀️ Día Suave",
  cozyDusk: "🌙 Atardecer",
  languageLabel: "Idioma",
  regionLabel: "Región (Fechas y números)",
  currencyLabel: "Moneda",
  studioTitle: "Crea tu personaje y sala ✨",
  thisIsMe: "¡Soy yo! 🫧",
  tabLook: "Aspecto",
  tabOutfit: "Ropa",
  tabExtras: "Extras",
  tabRoom: "Sala 🪴",
  organizeBtn: "Organizar ✨",
  schedules: { once: "Una vez", daily: "Cada día", weekly: "Semanal", sunday: "Cada domingo", monthly: "Cada mes", location: "En lugar guardado" },
  taskCategories: { general: "Diario", school: "Escuela", homework: "Tarea", shopping: "Compras", food: "Comida", selfcare: "Cuidado", errand: "Recado", money: "Dinero" },
  noteKinds: { all: "Todo", note: "Normal", checklist: "Lista", idea: "Idea", shopping: "Compras", reminder: "Aviso", memory: "Recuerdo" },
  habitFrequencies: { Daily: "Diario", "3x / week": "3x / semana", Weekends: "Fines de semana", Weekly: "Semanal" },
  giftStatuses: { Idea: "Idea", Shopping: "Comprando", Wrapped: "Envuelto", Given: "Entregado" },
  destPlan: "Plan",
  destReminder: "Recordatorio",
  destShopping: "Lista de compras",
  destNote: "Notas",
  destMoney: "Gastos",
  askButterSubtitle: "Escribe en cualquier idioma o incluso frases mixtas.",
  askButterPlaceholder: "Ej.: Recuérdame comprar champú mañana / I need to buy دفتر tomorrow",
  askButterExample1: "Necesito comprar un regalo mañana y terminar mi tarea por la noche.",
  askButterExample2: "I need to buy دفتر tomorrow a las 6 PM.",
  askButterChip1: "Prueba: \"Regalo mañana y tarea\"",
  askButterChip2: "Mixto: \"Buy دفتر tomorrow\"",
  confirmEditNote: "Confirma o edita antes de guardar:",
  confirmSaveItems: "Confirmar y guardar {count} elementos ✨",
  quickNewReminder: "Nuevo Recordatorio ⏰",
  quickAddSomething: "Añadir Algo 📝",
  quickWhatTodo: "¿Qué quieres hacer?",
  quickSaveBtn: "Guardar en BETTER",
  toastSavedAvatar: "Personaje y sala guardados 🫧",
  toastSavedItems: "{count} elementos guardados en BETTER ✨",
  errorGeneric: "Algo salió mal. Inténtalo de nuevo.",
};

const FR: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "Choisis ta langue 🌍",
  chooseLanguageSub: "BETTER adapte les textes, dates, calendriers et le sens d’affichage.",
  changeLaterNote: "Tu pourras changer de langue à tout moment dans les Réglages.",
  languageUpdatedToast: "Langue mise à jour 🌍",
  splashTagline: "Rends ta vie meilleure.",
  skip: "Passer",
  back: "Retour",
  continueBtn: "Continuer",
  getStarted: "Commencer ✨",
  slide1Title: "Bienvenue dans BETTER ✨",
  slide1Sub: "Ton petit compagnon du quotidien.",
  slide1Detail: "Un espace doux pour tes plans, notes, listes, dépenses et ton rythme.",
  slide2Title: "Organise ta journée 🌱",
  slide2Sub: "Garde tes plans, rappels, notes et listes au même endroit.",
  slide2Detail: "Écris naturellement dans n’importe quelle langue avec Ask BETTER ✨.",
  slide3Title: "Fais-en ton monde 🫧",
  slide3Sub: "Crée ton personnage et personnalise ton univers BETTER.",
  slide3Detail: "Habille ton compagnon et observe ses réactions chaleureuses.",
  navHome: "Accueil",
  navPlan: "Agenda",
  navNotes: "Notes",
  navMe: "Moi",
  askButter: "Ask BETTER",
  save: "Enregistrer",
  cancel: "Annuler",
  add: "Ajouter",
  deleteLabel: "Supprimer",
  editLabel: "Modifier",
  closeLabel: "Fermer",
  unlock: "Déverrouiller",
  hide: "Masquer",
  greetingMorning: "Bonjour !",
  greetingAfternoon: "Bon après-midi !",
  greetingEvening: "Bonsoir !",
  homePromptNamed: "Salut {name}, comment BETTER peut t’aider aujourd’hui ?",
  homePromptDefault: "Comment BETTER peut t’aider aujourd’hui ?",
  editRoom: "Modifier la pièce",
  localWeather: "Météo locale",
  useLocation: "Utiliser ma position",
  chooseCity: "Choisir une ville",
  moodTitle: "Humeur du jour 🫧",
  moodGreat: "Super",
  moodGood: "Bien",
  moodOkay: "Moyen",
  moodTired: "Fatigué",
  moodLow: "Pas top",
  quickAdd: "Ajouter",
  quickReminder: "Rappel",
  quickList: "Courses",
  quickMoney: "Budget",
  quickAskButter: "Ask BETTER",
  yourDay: "☀️ Aujourd’hui",
  makeDayEasier: "Alléger ma journée",
  fullPlan: "Tout voir",
  windDown: "Fin de journée 🌙",
  packAndGo: "Sac & Départ 🎒",
  exploreWorld: "Explorer ton monde BETTER",
  planTitle: "Calendrier & Agenda",
  planSubtitle: "Aujourd’hui, semaine, mois et rappels intelligents.",
  addPlan: "Nouveau plan",
  viewToday: "Aujourd’hui",
  viewWeek: "Semaine",
  viewMonth: "Mois",
  tomorrowLabel: "Demain",
  thisWeekLabel: "Cette semaine",
  notesTab: "Notes 📝",
  listsTab: "Listes 🛍️",
  memoriesTab: "Souvenirs 🫧",
  thingsTab: "Mes Affaires 📦",
  moneyTitle: "Budget",
  moneySub: "Tes dépenses et objectifs d’épargne en un coup d’œil.",
  addSpending: "Ajouter dépense",
  todaySpending: "Aujourd’hui",
  thisWeekSpending: "Cette semaine",
  thisMonthSpending: "Ce mois-ci",
  spendingByCategory: "Par catégorie",
  recentSpending: "Dépenses récentes",
  savingsGoals: "Objectifs d’épargne 🎯",
  newGoal: "Nouvel objectif",
  expenseCategories: { Food: "Repas", Shopping: "Achats", Transport: "Transport", Fun: "Loisirs", Bills: "Factures", "Self-Care": "Bien-être" },
  customizeAvatarRoom: "Personnaliser Avatar & Pièce ✨",
  myHabits: "Mes habitudes 🌱",
  myGoals: "Mes objectifs 🎯",
  achievementsTitle: "Réussites 🏆",
  personalizationTitle: "Apparence & Préférences",
  softDay: "☀️ Jour Doux",
  cozyDusk: "🌙 Soirée Douce",
  languageLabel: "Langue",
  regionLabel: "Région (Dates & Nombres)",
  currencyLabel: "Devise",
  studioTitle: "Crée ton personnage et ta pièce ✨",
  thisIsMe: "C’est moi ! 🫧",
  tabLook: "Look",
  tabOutfit: "Tenue",
  tabExtras: "Extras",
  tabRoom: "Pièce 🪴",
  organizeBtn: "Organiser ✨",
  schedules: { once: "Une fois", daily: "Chaque jour", weekly: "Chaque semaine", sunday: "Chaque dimanche", monthly: "Chaque mois", location: "Au lieu enregistré" },
  taskCategories: { general: "Quotidien", school: "École", homework: "Devoirs", shopping: "Achats", food: "Repas", selfcare: "Bien-être", errand: "Course", money: "Budget" },
  noteKinds: { all: "Tout", note: "Note", checklist: "Liste", idea: "Idée", shopping: "Achats", reminder: "Rappel", memory: "Souvenir" },
  habitFrequencies: { Daily: "Quotidien", "3x / week": "3x / semaine", Weekends: "Week-ends", Weekly: "Hebdomadaire" },
  giftStatuses: { Idea: "Idée", Shopping: "En cours", Wrapped: "Emballé", Given: "Offert" },
  destPlan: "Agenda",
  destReminder: "Rappel",
  destShopping: "Liste d’achats",
  destNote: "Notes",
  destMoney: "Dépenses",
  askButterSubtitle: "Écris dans n’importe quelle langue ou en mélangeant les langues.",
  askButterPlaceholder: "Ex. : Rappelle-moi d’acheter du shampoing demain / I need to buy دفتر tomorrow",
  askButterExample1: "Je dois acheter un cadeau d’anniversaire demain et finir mes devoirs ce soir.",
  askButterExample2: "I need to buy دفتر tomorrow à 18h.",
  askButterChip1: "Essayer : \"Cadeau demain & devoirs\"",
  askButterChip2: "Mixte : \"Buy دفتر tomorrow\"",
  confirmEditNote: "Confirme ou modifie avant d’enregistrer :",
  confirmSaveItems: "Confirmer et enregistrer {count} éléments ✨",
  quickNewReminder: "Nouveau Rappel ⏰",
  quickAddSomething: "Ajouter 📝",
  quickWhatTodo: "Que veux-tu faire ?",
  quickSaveBtn: "Enregistrer dans BETTER",
  toastSavedAvatar: "Personnage et pièce enregistrés 🫧",
  toastSavedItems: "{count} éléments enregistrés dans BETTER ✨",
  errorGeneric: "Une erreur s’est produite. Réessaie.",
};

const DE: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "Wähle deine Sprache 🌍",
  chooseLanguageSub: "BETTER passt Texte, Daten, Kalender und Leserichtung automatisch an.",
  changeLaterNote: "Du kannst deine Sprache jederzeit in den Einstellungen ändern.",
  languageUpdatedToast: "Sprache aktualisiert 🌍",
  splashTagline: "Mach dein Leben besser.",
  skip: "Überspringen",
  back: "Zurück",
  continueBtn: "Weiter",
  getStarted: "Los geht’s ✨",
  slide1Title: "Willkommen bei BETTER ✨",
  slide1Sub: "Dein kleiner Begleiter für jeden Tag.",
  slide1Detail: "Ein ruhiger Ort für Pläne, Notizen, Einkaufslisten, Geld und Gewohnheiten.",
  slide2Title: "Organisiere deinen Tag 🌱",
  slide2Sub: "Behalte Pläne, Erinnerungen, Notizen und Listen an einem Ort.",
  slide2Detail: "Schreibe natürlich in jeder Sprache mit Ask BETTER ✨.",
  slide3Title: "Mach es zu deinem 🫧",
  slide3Sub: "Erstelle deine eigene Figur und gestalte deine BETTER-Welt.",
  slide3Detail: "Kleide deinen Begleiter ein und erlebe liebevolle Reaktionen.",
  navHome: "Start",
  navPlan: "Plan",
  navNotes: "Notizen",
  navMe: "Ich",
  askButter: "Frag BETTER",
  save: "Speichern",
  cancel: "Abbrechen",
  add: "Neu",
  deleteLabel: "Löschen",
  editLabel: "Bearbeiten",
  closeLabel: "Schließen",
  unlock: "Entsperren",
  hide: "Ausblenden",
  greetingMorning: "Guten Morgen!",
  greetingAfternoon: "Guten Tag!",
  greetingEvening: "Guten Abend!",
  homePromptNamed: "Hallo {name}, wie kann BETTER dir heute helfen?",
  homePromptDefault: "Wie kann BETTER dir heute helfen?",
  editRoom: "Zimmer bearbeiten",
  localWeather: "Wetter vor Ort",
  useLocation: "Standort nutzen",
  chooseCity: "Stadt wählen",
  moodTitle: "Stimmung 🫧",
  moodGreat: "Super",
  moodGood: "Gut",
  moodOkay: "Okay",
  moodTired: "Müde",
  moodLow: "Nicht gut",
  quickAdd: "Neu",
  quickReminder: "Erinnerung",
  quickList: "Einkauf",
  quickMoney: "Geld",
  quickAskButter: "Frag BETTER",
  yourDay: "☀️ Heute",
  makeDayEasier: "Tag erleichtern",
  fullPlan: "Ganzer Plan",
  windDown: "Abendruhe 🌙",
  packAndGo: "Packliste 🎒",
  exploreWorld: "Entdecke deine BETTER-Welt",
  planTitle: "Kalender & Plan",
  planSubtitle: "Heute, Woche, Monat und smarte Erinnerungen.",
  addPlan: "Plan hinzufügen",
  viewToday: "Heute",
  viewWeek: "Woche",
  viewMonth: "Monat",
  tomorrowLabel: "Morgen",
  thisWeekLabel: "Diese Woche",
  notesTab: "Notizen 📝",
  listsTab: "Listen 🛍️",
  memoriesTab: "Erinnerungen 🫧",
  thingsTab: "Meine Sachen 📦",
  moneyTitle: "Geld",
  moneySub: "Ausgaben und Sparziele entspannt im Blick.",
  addSpending: "Ausgabe",
  todaySpending: "Heute ausgegeben",
  thisWeekSpending: "Diese Woche",
  thisMonthSpending: "Dieser Monat",
  spendingByCategory: "Ausgaben nach Kategorie",
  recentSpending: "Letzte Ausgaben",
  savingsGoals: "Sparziele 🎯",
  newGoal: "Neues Ziel",
  expenseCategories: { Food: "Essen", Shopping: "Einkauf", Transport: "Weg", Fun: "Freizeit", Bills: "Rechnung", "Self-Care": "Pflege" },
  customizeAvatarRoom: "Figur & Zimmer anpassen ✨",
  myHabits: "Meine Gewohnheiten 🌱",
  myGoals: "Meine Ziele 🎯",
  achievementsTitle: "Erfolge 🏆",
  personalizationTitle: "Design & Anpassung",
  softDay: "☀️ Sanfter Tag",
  cozyDusk: "🌙 Gemütlicher Abend",
  languageLabel: "Sprache",
  regionLabel: "Region (Datum & Zahlen)",
  currencyLabel: "Währung",
  studioTitle: "Erstelle Figur & Zimmer ✨",
  thisIsMe: "Das bin ich! 🫧",
  tabLook: "Look",
  tabOutfit: "Outfit",
  tabExtras: "Extras",
  tabRoom: "Zimmer 🪴",
  organizeBtn: "Ordnen ✨",
  schedules: { once: "Einmalig", daily: "Täglich", weekly: "Wöchentlich", sunday: "Jeden Sonntag", monthly: "Monatlich", location: "Am gespeicherten Ort" },
  taskCategories: { general: "Alltag", school: "Schule", homework: "Lernen", shopping: "Einkauf", food: "Essen", selfcare: "Pflege", errand: "Erledigung", money: "Geld" },
  noteKinds: { all: "Alle", note: "Notiz", checklist: "Liste", idea: "Idee", shopping: "Einkauf", reminder: "Erinnerung", memory: "Erinnerung" },
  habitFrequencies: { Daily: "Täglich", "3x / week": "3x / Woche", Weekends: "Wochenende", Weekly: "Wöchentlich" },
  giftStatuses: { Idea: "Idee", Shopping: "Kaufen", Wrapped: "Verpackt", Given: "Verschenkt" },
  destPlan: "Plan",
  destReminder: "Erinnerung",
  destShopping: "Einkaufsliste",
  destNote: "Notizen",
  destMoney: "Ausgaben",
  askButterSubtitle: "Schreibe in jeder Sprache – auch gemischte Sätze.",
  askButterPlaceholder: "z. B. Erinnere mich morgen an Shampoo / I need to buy دفتر tomorrow",
  askButterExample1: "Ich muss morgen ein Geburtstagsgeschenk kaufen und abends lernen.",
  askButterExample2: "I need to buy دفتر tomorrow um 18 Uhr.",
  askButterChip1: "Test: \"Geschenk morgen & Lernen\"",
  askButterChip2: "Gemischt: \"Buy دفتر tomorrow\"",
  confirmEditNote: "Vor dem Speichern prüfen oder anpassen:",
  confirmSaveItems: "{count} Einträge bestätigen & speichern ✨",
  quickNewReminder: "Neue Erinnerung ⏰",
  quickAddSomething: "Etwas hinzufügen 📝",
  quickWhatTodo: "Was möchtest du tun?",
  quickSaveBtn: "In BETTER speichern",
  toastSavedAvatar: "Figur & Zimmer gespeichert 🫧",
  toastSavedItems: "{count} Einträge in BETTER gespeichert ✨",
  errorGeneric: "Etwas ist schiefgelaufen. Bitte erneut versuchen.",
};

const KO: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "언어를 선택하세요 🌍",
  chooseLanguageSub: "BETTER가 텍스트, 날짜, 달력, 화면 방향을 자동으로 맞춰줍니다.",
  changeLaterNote: "언어는 언제든지 설정에서 다시 바꿀 수 있어요.",
  languageUpdatedToast: "언어가 변경되었어요 🌍",
  splashTagline: "더 나은 일상을 만들어요.",
  skip: "건너뛰기",
  back: "뒤로",
  continueBtn: "계속",
  getStarted: "시작하기 ✨",
  slide1Title: "BETTER에 오신 걸 환영해요 ✨",
  slide1Sub: "매일 함께하는 작은 일상 동반자.",
  slide1Detail: "일정, 메모, 장보기 목록, 소비, 습관을 포근한 공간에서 관리해요.",
  slide2Title: "하루를 정리해요 🌱",
  slide2Sub: "계획, 알림, 메모, 리스트를 한곳에 모아두세요.",
  slide2Detail: "Ask BETTER ✨에 어떤 언어로든 편하게 입력하면 깔끔한 카드로 정리해줘요.",
  slide3Title: "나만의 공간 만들기 🫧",
  slide3Sub: "나만의 캐릭터를 만들고 BETTER 월드를 꾸며보세요.",
  slide3Detail: "캐릭터를 꾸미고 하루 동안 다정한 반응을 만나보세요.",
  navHome: "홈",
  navPlan: "일정",
  navNotes: "메모",
  navMe: "나",
  askButter: "Ask BETTER",
  save: "저장",
  cancel: "취소",
  add: "추가",
  deleteLabel: "삭제",
  editLabel: "수정",
  closeLabel: "닫기",
  unlock: "잠금 해제",
  hide: "숨기기",
  greetingMorning: "좋은 아침이에요!",
  greetingAfternoon: "포근한 오후예요!",
  greetingEvening: "편안한 저녁이에요!",
  homePromptNamed: "{name}님, 오늘 BETTER가 무엇을 도와줄까요?",
  homePromptDefault: "오늘 BETTER가 무엇을 도와줄까요?",
  editRoom: "방 꾸미기",
  localWeather: "오늘의 날씨",
  useLocation: "위치 사용",
  chooseCity: "도시 선택",
  moodTitle: "오늘의 기분 🫧",
  moodGreat: "최고예요",
  moodGood: "좋아요",
  moodOkay: "보통",
  moodTired: "피곤해요",
  moodLow: "조금 지쳐요",
  quickAdd: "추가",
  quickReminder: "알림",
  quickList: "쇼핑",
  quickMoney: "지출",
  quickAskButter: "Ask BETTER",
  yourDay: "☀️ 오늘",
  makeDayEasier: "하루 순서 정리",
  fullPlan: "전체 일정",
  windDown: "저녁 마무리 🌙",
  packAndGo: "챙길 것 🎒",
  exploreWorld: "BETTER 공간 둘러보기",
  planTitle: "스마트 캘린더 & 일정",
  planSubtitle: "오늘, 이번 주, 이번 달과 스마트 알림.",
  addPlan: "일정 추가",
  viewToday: "오늘",
  viewWeek: "주간",
  viewMonth: "월간",
  tomorrowLabel: "내일",
  thisWeekLabel: "이번 주",
  notesTab: "메모 📝",
  listsTab: "리스트 🛍️",
  memoriesTab: "추억 🫧",
  thingsTab: "내 물건 📦",
  moneyTitle: "지출 관리",
  moneySub: "소비 기록과 저축 목표를 차분하게 확인해요.",
  addSpending: "지출 기록",
  todaySpending: "오늘 지출",
  thisWeekSpending: "이번 주",
  thisMonthSpending: "이번 달",
  spendingByCategory: "카테고리별 지출",
  recentSpending: "최근 지출",
  savingsGoals: "저축 목표 🎯",
  newGoal: "새 목표",
  expenseCategories: { Food: "식비", Shopping: "쇼핑", Transport: "교통", Fun: "여가", Bills: "공과금", "Self-Care": "자기관리" },
  customizeAvatarRoom: "캐릭터 & 방 꾸미기 ✨",
  myHabits: "나의 습관 🌱",
  myGoals: "나의 목표 🎯",
  achievementsTitle: "성취 기록 🏆",
  personalizationTitle: "화면 및 테마 설정",
  softDay: "☀️ 부드러운 낮",
  cozyDusk: "🌙 포근한 밤",
  languageLabel: "언어",
  regionLabel: "지역 (날짜 및 숫자)",
  currencyLabel: "통화",
  studioTitle: "나만의 캐릭터와 방 만들기 ✨",
  thisIsMe: "바로 나예요! 🫧",
  tabLook: "외모",
  tabOutfit: "의상",
  tabExtras: "소품",
  tabRoom: "방 🪴",
  organizeBtn: "정리하기 ✨",
  schedules: { once: "한 번", daily: "매일", weekly: "매주", sunday: "매주 일요일", monthly: "매달", location: "저장된 장소에서" },
  taskCategories: { general: "일상", school: "학교", homework: "과제", shopping: "쇼핑", food: "음식", selfcare: "셀프케어", errand: "심부름", money: "지출" },
  noteKinds: { all: "전체", note: "일반", checklist: "체크리스트", idea: "아이디어", shopping: "쇼핑", reminder: "알림", memory: "추억" },
  habitFrequencies: { Daily: "매일", "3x / week": "주 3회", Weekends: "주말", Weekly: "매주" },
  giftStatuses: { Idea: "아이디어", Shopping: "구매 중", Wrapped: "포장 완료", Given: "전달 완료" },
  destPlan: "일정",
  destReminder: "알림",
  destShopping: "장보기 목록",
  destNote: "메모",
  destMoney: "지출 기록",
  askButterSubtitle: "어떤 언어든, 섞인 문장도 자연스럽게 이해해요.",
  askButterPlaceholder: "예: 내일 샴푸 사라고 알려줘 / I need to buy دفتر tomorrow",
  askButterExample1: "내일 생일 선물 사고 밤에는 숙제를 끝내야 해.",
  askButterExample2: "I need to buy دفتر tomorrow 오후 6시에 알려줘.",
  askButterChip1: "예시: \"내일 선물 & 숙제\"",
  askButterChip2: "혼합: \"Buy دفتر tomorrow\"",
  confirmEditNote: "저장하기 전에 확인하거나 수정하세요:",
  confirmSaveItems: "{count}개 항목 저장하기 ✨",
  quickNewReminder: "새 알림 ⏰",
  quickAddSomething: "새 항목 추가 📝",
  quickWhatTodo: "무엇을 할까요?",
  quickSaveBtn: "BETTER에 저장",
  toastSavedAvatar: "캐릭터와 방이 저장되었어요 🫧",
  toastSavedItems: "{count}개 항목을 BETTER에 저장했어요 ✨",
  errorGeneric: "문제가 발생했어요. 다시 시도해주세요.",
};

const JA: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "言語を選択 🌍",
  chooseLanguageSub: "テキスト、日付、カレンダー、表示方向を自動で合わせます。",
  changeLaterNote: "言語は設定からいつでも変更できます。",
  languageUpdatedToast: "言語を更新しました 🌍",
  splashTagline: "毎日をもっと心地よく。",
  skip: "スキップ",
  back: "戻る",
  continueBtn: "次へ",
  getStarted: "はじめる ✨",
  slide1Title: "BETTERへようこそ ✨",
  slide1Sub: "毎日によりそう、小さな暮らしのパートナー。",
  slide1Detail: "予定、メモ、買い物リスト、お金、習慣をひとつの穏やかな場所に。",
  slide2Title: "1日をととのえる 🌱",
  slide2Sub: "予定やリマインダー、メモ、リストをまとめて管理。",
  slide2Detail: "Ask BETTER ✨なら自然な言葉で書くだけで、きれいなカードに整理します。",
  slide3Title: "自分だけの世界に 🫧",
  slide3Sub: "キャラクターを作って、あなたのBETTER空間をカスタマイズ。",
  slide3Detail: "お気に入りの服を着せて、日々のリアクションを楽しもう。",
  navHome: "ホーム",
  navPlan: "予定",
  navNotes: "メモ",
  navMe: "マイ",
  askButter: "Ask BETTER",
  save: "保存",
  cancel: "キャンセル",
  add: "追加",
  deleteLabel: "削除",
  editLabel: "編集",
  closeLabel: "閉じる",
  unlock: "解除",
  hide: "非表示",
  greetingMorning: "おはようございます！",
  greetingAfternoon: "こんにちは！",
  greetingEvening: "こんばんは！",
  homePromptNamed: "{name}さん、今日のBETTERは何をお手伝いしましょう？",
  homePromptDefault: "今日は何をお手伝いしましょう？",
  editRoom: "部屋を編集",
  localWeather: "天気",
  useLocation: "位置情報を使う",
  chooseCity: "都市を選ぶ",
  moodTitle: "今日の気分 🫧",
  moodGreat: "最高",
  moodGood: "良い",
  moodOkay: "ふつう",
  moodTired: "お疲れ",
  moodLow: "いまひとつ",
  quickAdd: "追加",
  quickReminder: "通知",
  quickList: "買い物",
  quickMoney: "お金",
  quickAskButter: "Ask BETTER",
  yourDay: "☀️ 今日",
  makeDayEasier: "順番を提案",
  fullPlan: "予定一覧",
  windDown: "夜のじたく 🌙",
  packAndGo: "持ち物 🎒",
  exploreWorld: "BETTERの世界を開く",
  planTitle: "カレンダー & 予定",
  planSubtitle: "今日、今週、今月とスマートリマインダー。",
  addPlan: "予定を追加",
  viewToday: "今日",
  viewWeek: "週",
  viewMonth: "月",
  tomorrowLabel: "明日",
  thisWeekLabel: "今週",
  notesTab: "メモ 📝",
  listsTab: "リスト 🛍️",
  memoriesTab: "思い出 🫧",
  thingsTab: "持ち物メモ 📦",
  moneyTitle: "お金の記録",
  moneySub: "支出と貯金目標をシンプルに確認できます。",
  addSpending: "支出を追加",
  todaySpending: "今日の支出",
  thisWeekSpending: "今週",
  thisMonthSpending: "今月",
  spendingByCategory: "カテゴリ別の支出",
  recentSpending: "最近の支出",
  savingsGoals: "貯金目標 🎯",
  newGoal: "新しい目標",
  expenseCategories: { Food: "食事", Shopping: "買い物", Transport: "交通", Fun: "趣味", Bills: "固定費", "Self-Care": "セルフケア" },
  customizeAvatarRoom: "キャラと部屋を編集 ✨",
  myHabits: "習慣 🌱",
  myGoals: "目標 🎯",
  achievementsTitle: "マイルストーン 🏆",
  personalizationTitle: "デザインと設定",
  softDay: "☀️ やさしい昼",
  cozyDusk: "🌙 くつろぎ夜",
  languageLabel: "言語",
  regionLabel: "地域（日付と数値）",
  currencyLabel: "通貨",
  studioTitle: "キャラとお部屋を作ろう ✨",
  thisIsMe: "これで決定！ 🫧",
  tabLook: "見た目",
  tabOutfit: "服",
  tabExtras: "小物",
  tabRoom: "部屋 🪴",
  organizeBtn: "整理する ✨",
  schedules: { once: "1回のみ", daily: "毎日", weekly: "毎週", sunday: "毎週日曜", monthly: "毎月", location: "登録した場所で" },
  taskCategories: { general: "毎日", school: "学校", homework: "宿題", shopping: "買い物", food: "食事", selfcare: "ケア", errand: "用事", money: "お金" },
  noteKinds: { all: "すべて", note: "メモ", checklist: "チェック", idea: "アイデア", shopping: "買い物", reminder: "通知", memory: "思い出" },
  habitFrequencies: { Daily: "毎日", "3x / week": "週3回", Weekends: "週末", Weekly: "毎週" },
  giftStatuses: { Idea: "アイデア", Shopping: "購入中", Wrapped: "ラッピング済", Given: "渡した" },
  destPlan: "予定",
  destReminder: "リマインダー",
  destShopping: "買い物リスト",
  destNote: "メモ",
  destMoney: "支出ログ",
  askButterSubtitle: "どの言語でも、混ざった文章でも自然に理解します。",
  askButterPlaceholder: "例：明日シャンプーを買うのを思い出させて / I need to buy دفتر tomorrow",
  askButterExample1: "明日誕生日プレゼントを買って、夜に宿題を終わらせたい。",
  askButterExample2: "I need to buy دفتر tomorrow 夕方6時にリマインド。",
  askButterChip1: "試す: \"明日のギフトと宿題\"",
  askButterChip2: "混合: \"Buy دفتر tomorrow\"",
  confirmEditNote: "保存前に確認・編集してください：",
  confirmSaveItems: "{count}件を確定して保存 ✨",
  quickNewReminder: "新しいリマインダー ⏰",
  quickAddSomething: "予定を追加 📝",
  quickWhatTodo: "何をしますか？",
  quickSaveBtn: "BETTERに保存",
  toastSavedAvatar: "キャラとお部屋を保存しました 🫧",
  toastSavedItems: "{count}件をBETTERに保存しました ✨",
  errorGeneric: "エラーが発生しました。もう一度お試しください。",
};

const ZH: TranslationBundle = {
  ...EN,
  chooseLanguageTitle: "选择你的语言 🌍",
  chooseLanguageSub: "BETTER 会为你自动调整界面文字、日期、日历和排版方向。",
  changeLaterNote: "你随时可以在设置中更改语言。",
  languageUpdatedToast: "语言已更新 🌍",
  splashTagline: "让生活更美好。",
  skip: "跳过",
  back: "返回",
  continueBtn: "继续",
  getStarted: "开始使用 ✨",
  slide1Title: "欢迎来到 BETTER ✨",
  slide1Sub: "你的贴心日常小伴侣。",
  slide1Detail: "把每日计划、笔记、购物清单、记账和习惯安放在温柔的小世界里。",
  slide2Title: "理清你的每一天 🌱",
  slide2Sub: "在一个地方记录计划、提醒、笔记和清单。",
  slide2Detail: "用任何语言对 Ask BETTER ✨ 自然表达，自动整理成清晰卡片。",
  slide3Title: "打造你的专属空间 🫧",
  slide3Sub: "创建属于你的小角色，装扮你的 BETTER 世界。",
  slide3Detail: "为角色搭配穿搭与房间，它会陪你度过每天的点滴。",
  navHome: "首页",
  navPlan: "计划",
  navNotes: "笔记",
  navMe: "我的",
  askButter: "问 BETTER",
  save: "保存",
  cancel: "取消",
  add: "添加",
  deleteLabel: "删除",
  editLabel: "编辑",
  closeLabel: "关闭",
  unlock: "解锁",
  hide: "隐藏",
  greetingMorning: "早上好！",
  greetingAfternoon: "下午好！",
  greetingEvening: "晚上好！",
  homePromptNamed: "你好 {name}，今天 BETTER 可以帮你做什么？",
  homePromptDefault: "今天 BETTER 可以帮你做什么？",
  editRoom: "装扮房间",
  localWeather: "本地天气",
  useLocation: "使用定位",
  chooseCity: "选择城市",
  moodTitle: "今日心情 🫧",
  moodGreat: "超棒",
  moodGood: "不错",
  moodOkay: "平静",
  moodTired: "有点累",
  moodLow: "不太好",
  quickAdd: "添加",
  quickReminder: "提醒",
  quickList: "购物",
  quickMoney: "记账",
  quickAskButter: "问 BETTER",
  yourDay: "☀️ 今天",
  makeDayEasier: "帮我理顺今天",
  fullPlan: "完整计划",
  windDown: "睡前准备 🌙",
  packAndGo: "出行打包 🎒",
  exploreWorld: "探索 BETTER 世界",
  planTitle: "智能日历与计划",
  planSubtitle: "今日、本周、本月安排与智能提醒。",
  addPlan: "添加计划",
  viewToday: "今日",
  viewWeek: "本周",
  viewMonth: "本月",
  tomorrowLabel: "明天",
  thisWeekLabel: "本周",
  notesTab: "笔记 📝",
  listsTab: "清单 🛍️",
  memoriesTab: "回忆 🫧",
  thingsTab: "物品收纳 📦",
  moneyTitle: "记账与储蓄",
  moneySub: "在安静清晰的视图中查看花销与储蓄目标。",
  addSpending: "记一笔",
  todaySpending: "今日花销",
  thisWeekSpending: "本周花销",
  thisMonthSpending: "本月花销",
  spendingByCategory: "分类统计",
  recentSpending: "近期消费",
  savingsGoals: "储蓄目标 🎯",
  newGoal: "新目标",
  expenseCategories: { Food: "餐饮", Shopping: "购物", Transport: "交通", Fun: "娱乐", Bills: "账单", "Self-Care": "护理" },
  customizeAvatarRoom: "装扮角色与房间 ✨",
  myHabits: "我的习惯 🌱",
  myGoals: "我的目标 🎯",
  achievementsTitle: "成长成就 🏆",
  personalizationTitle: "个性化与外观",
  softDay: "☀️ 柔和日间",
  cozyDusk: "🌙 暖意夜间",
  languageLabel: "语言",
  regionLabel: "地区（日期与数字）",
  currencyLabel: "货币",
  studioTitle: "创建你的角色与房间 ✨",
  thisIsMe: "这就是我！ 🫧",
  tabLook: "外貌",
  tabOutfit: "穿搭",
  tabExtras: "配饰",
  tabRoom: "房间 🪴",
  organizeBtn: "整理 ✨",
  schedules: { once: "仅一次", daily: "每天", weekly: "每周", sunday: "每周日", monthly: "每月", location: "到达保存地点时" },
  taskCategories: { general: "日常", school: "学习", homework: "作业", shopping: "购物", food: "餐饮", selfcare: "自我照顾", errand: "杂事", money: "记账" },
  noteKinds: { all: "全部", note: "笔记", checklist: "清单", idea: "灵感", shopping: "购物", reminder: "提醒", memory: "回忆" },
  habitFrequencies: { Daily: "每天", "3x / week": "每周3次", Weekends: "周末", Weekly: "每周" },
  giftStatuses: { Idea: "想法", Shopping: "购买中", Wrapped: "已包装", Given: "已送出" },
  destPlan: "计划",
  destReminder: "提醒",
  destShopping: "购物清单",
  destNote: "笔记",
  destMoney: "记账",
  askButterSubtitle: "支持所有语言及混合语言输入。",
  askButterPlaceholder: "例如：提醒我明天买洗发水 / I need to buy دفتر tomorrow",
  askButterExample1: "明天需要买生日礼物，晚上完成作业。",
  askButterExample2: "I need to buy دفتر tomorrow 晚上6点提醒我。",
  askButterChip1: "试试：\"明天买礼物和写作业\"",
  askButterChip2: "混合：\"Buy دفتر tomorrow\"",
  confirmEditNote: "保存前请确认或修改：",
  confirmSaveItems: "确认并保存 {count} 项 ✨",
  quickNewReminder: "新建提醒 ⏰",
  quickAddSomething: "添加事项 📝",
  quickWhatTodo: "你想做什么？",
  quickSaveBtn: "保存到 BETTER",
  toastSavedAvatar: "角色与房间已保存 🫧",
  toastSavedItems: "已保存 {count} 项到 BETTER ✨",
  errorGeneric: "出现了一点问题，请重试。",
};

export const TRANSLATIONS: Record<AppLanguage, TranslationBundle> = {
  en: EN,
  ar: AR,
  ckb: CKB,
  tr: TR,
  es: ES,
  fr: FR,
  de: DE,
  ko: KO,
  ja: JA,
  zh: ZH,
};

export function t(language: AppLanguage): TranslationBundle {
  return TRANSLATIONS[language] || EN;
}

export function fmt(template: string, vars: Record<string, string | number>): string {
  let out = template;
  for (const [k, v] of Object.entries(vars)) {
    out = out.replaceAll(`{${k}}`, String(v));
  }
  return out;
}

export function getLocalizedWeatherText(
  code: number,
  tempC: number,
  language: AppLanguage
): { condition: string; advice: string } {
  const tr = t(language);
  const condition =
    code === 0
      ? tr.weatherClear
      : code <= 3
        ? tr.weatherCloudy
        : code <= 48
          ? tr.weatherMisty
          : code <= 67 || (code >= 80 && code <= 82)
            ? tr.weatherRain
            : code <= 77 || (code >= 85 && code <= 86)
              ? tr.weatherSnow
              : tr.weatherStorm;

  let advice = tr.adviceCloudy;
  if (code >= 51 && (code <= 67 || (code >= 80 && code <= 82))) {
    advice = tr.adviceRain;
  } else if (code >= 71 && (code <= 77 || code >= 85)) {
    advice = tr.adviceSnow;
  } else if (tempC <= 12) {
    advice = tr.adviceChilly;
  } else if (tempC <= 20) {
    advice = tr.adviceCool;
  } else if (tempC >= 30) {
    advice = tr.adviceWarm;
  } else if (code === 0) {
    advice = tr.adviceClear;
  }

  return { condition, advice };
}
